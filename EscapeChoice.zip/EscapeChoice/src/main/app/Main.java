package main.app;

import main.model.*;
import main.controller.*;
import main.view.*;

/**
 * Classe Main.
 * Avvia l'applicazione Escape Choice.
 * 
 * Punto di ingresso dell'app: creazione e collegamento delle istanze Model, Controller e View,
 * secondo il pattern MVC.
 */
public class Main {

    /**
     * @param args the command line arguments
     */
	public static void main(String[] args) {

        // Creazione del Model (gestisce logica e stato di gioco)
        Model model = new ModelImpl();

        // Creazione del Controller, collegato al Model
        Controller controller = new ControllerImpl(model);

        // Creazione della View, collegata al Controller
        View view = new ViewImpl(controller);

        // La View si registra come listener del Model e riceverà notifiche sugli aggiornamenti
        model.addListener((ModelListener) view);

        // Avvio della GUI (schermata iniziale)
        view.start();

	}

}
