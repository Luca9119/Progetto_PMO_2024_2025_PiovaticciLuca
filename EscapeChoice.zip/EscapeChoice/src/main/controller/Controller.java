package main.controller;

import main.model.game.Difficulty;

/**
 * Interfaccia Controller dell'MVC che rappresenta il Controller.
 * Espone i metodi che la View può invocare per comunicare le azioni dell'utente al Model.
 */
public interface Controller {
	
    /**
     * Avvia una nuova partita impostando il nome del giocatore e la difficoltà
     * (attraverso la GUI).
     * 
     * @param playerName il nome inserito dall'utente
     * @param difficulty la difficoltà selezionata dall'utente
     */
    void startGame(String playerName, Difficulty difficulty);
    
    /**
     * Gestisce la scelta selezionata dall’utente tramite indice.
     * 
     * @param index indice della scelta
     */    
    void handleChoiceIndex(int index);
    
    /**
     * Salva lo stato attuale del gioco in un file binario tramite serializzazione Java.
     * 
     * @param path percorso del file su cui salvare
     */
    void saveGame(String path);

    /**
     * Carica lo stato del gioco da un file binario precedentemente salvato tramite serializzazione Java.
     * 
     * @param path percorso del file da cui caricare
     */
    void loadGame(String path);        

    /**
     * Riavvia il gioco azzerando il suo stato attuale e ripartendo da zero.
     * 
     * NOTA: Questo metodo non è utilizzato nella versione attuale, 
     * ma è mantenuto per possibili implementazioni future.
     */
    //void restartGame();	

}
