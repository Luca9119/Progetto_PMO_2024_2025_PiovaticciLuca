package main.controller;

import main.model.Model;
import main.model.game.Difficulty;

/**
 * Implementazione dell'interfaccia Controller.
 */
public class ControllerImpl implements Controller {
	
    // Riferimento al Model
    private final Model model;
	
    /**
     * Costruttore del Controller: riceve il Model da controllare.
     * 
     * @param model il modello logico del gioco
     */    
	public ControllerImpl(Model model) {
		this.model = model;
	}

	@Override
	public void startGame(String playerName, Difficulty difficulty) {
		this.model.startNewGame(playerName, difficulty);
	}
	
	@Override
	public void handleChoiceIndex(int index) {
	    // Chiede al Model di eseguire la scelta in base all’indice ricevuto dalla View.
	    // La View non conosce gli oggetti StoryChoice, passa solo un intero
	    this.model.chooseByIndex(index);
	}	
	
	@Override
	public void saveGame(String path) {
		this.model.saveGame(path);
	}

	@Override
	public void loadGame(String path) {
		this.model.loadGame(path);
	}	
	
	// Non utilizzato in questa versione del gioco.
	/*
	@Override
	public void restartGame() {
		this.model.restart();
	}
	*/

}
