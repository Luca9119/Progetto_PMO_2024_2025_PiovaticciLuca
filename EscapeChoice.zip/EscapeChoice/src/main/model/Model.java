package main.model;

import java.util.List;

import main.model.game.Difficulty;
import main.model.game.GameState;
import main.model.player.Player;
import main.model.story.Room;

/**
 * Interfaccia Model dell'MVC che rappresenta il modello logico del gioco.
 * Fornisce metodi al Controller.
 */
public interface Model {
	
    /**
     * Inizializza e avvia una nuova partita creando internamente Game e Player.
     * 
     * @param playerName il nome del giocatore (sarà inserito dall'utente)
     * @param difficulty la difficoltà del gioco (sarà inserita dall'utente) 
     */
    void startNewGame(String playerName, Difficulty difficulty);

    /**
     * Restituisce lo stato attuale della partita.
     * 
     * @return un valore dell'enumerazione GameState
     */
    GameState getGameState();
    
    /**
     * Imposta lo stato attuale della partita.
     * 
     * @param state lo stato da impostare
     */
    void setGameState(GameState state);
    
    /**
     * Restituisce i giocatori della partita.
     * 
     * @return List<Player> lista di Players
     */
    List<Player> getPlayers();    
	
    /**
     * Restituisce il giocatore passato come parametro.
	 * 
	 * Può lanciare un'eccezione se il giocatore non è presente nella partita.
     * 
     * @param playerName il nome del giocatore da restituire
     * 
     * @return Player il giocatore se presente nella partita
     * 
     * @throws IllegalStateException se il giocatore non è presente
     */
    Player getPlayer(String playerName);
    
    /**
     * Restituisce il livello di difficoltà impostato per la partita.
     * 
     * @return un valore dell'enumerazione Difficulty
     */
    Difficulty getDifficulty();    
	
    /**
     * Restituisce la scena corrente in cui si trova il giocatore.
     * 
     * @return Room la scena attuale
     */
    Room getCurrentRoom();
    
    /**
     * Restituisce e svuota la lista dei messaggi pendenti.
     * 
     * Ogni chiamata restituisce una copia della lista di messaggi attuali,
     * e li rimuove dalla coda interna, in modo che non vengano mostrati più volte.
     * 
     * @return List<String> lista contenente i messaggi
     */    
    List<String> usePendingMessages();  
    
    /**
     * Applica la scelta selezionata tramite indice.
     * 
     * @param index indice della scelta
     */    
    void chooseByIndex(int index);
    
    /**
     * Salva lo stato attuale del gioco in un file binario tramite serializzazione Java.
     * 
     * @param path percorso del file su cui salvare
     */
    void saveGame(String path);

    /**
     * Carica lo stato del gioco da un file binario precedentemente salvato tramite serializzazione Java.
     * 
     * @param path percorso del file da cui caricare
     */
    void loadGame(String path);

    /**
     * Aggiunge un nuovo listener (View) sul Model.
     * Permette alla View di ricevere notifiche sugli eventi del gioco.
     * 
     * @param l il listener da aggiungere
     */    
	void addListener(ModelListener l);

	/**
	 * Rimuove un listener (View) dal Model.
	 * Utile se la View viene chiusa o sostituita e non deve più ricevere notifiche.
	 * 
	 * @param l il listener da rimuovere
	 */	
	void removeListener(ModelListener l);

    /**
     * Riavvia il gioco azzerando il suo stato attuale e ripartendo da zero.
     * 
     * NOTA: Questo metodo non è utilizzato nella versione attuale, 
     * ma è mantenuto per possibili implementazioni future.
     */
    //void restart();  

}
