package main.model;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;

import main.model.game.Difficulty;
import main.model.game.Game;
import main.model.game.GameImpl;
import main.model.game.GameState;
import main.model.game.StoryOneDTO;
import main.model.player.Player;
import main.model.player.PlayerImpl;
import main.model.player.PlayerState;
import main.model.player.Inventory;
import main.model.player.InventoryImpl;
import main.model.player.Infection;
import main.model.player.InfectionImpl;
import main.model.story.Room;
import main.model.story.StoryChoice;
import main.view.ViewTexts;

/**
 * Implementazione dell'interfaccia Model.
 */
public class ModelImpl implements Model {
	
	private Game game;
	
	// Lista dei listener registrati sul Model.
	// La View riceve una notifica quando deve aggiornare le componenti dell'interfaccia grafica.
	private final List<ModelListener> listeners = new ArrayList<>();

	/**
	 * Costruttore del Model.
	 * 
	 * Non riceve un'istanza di Game come parametro, in quanto la creazione
	 * e l'inizializzazione del gioco devono essere gestite internamente dal Model tramite il metodo startNewGame.
	 * 
	 * Questo approccio evita di dover istanziare Game nel Main e poi passarla al Model,
	 * mantenendo l'incapsulamento e rispettando il pattern MVC:
	 * _ il Main crea solo le istanze di Model, View e Controller;
	 * _ il Model è l'unico responsabile della creazione e gestione di Game.
	 */	
	public ModelImpl() {}

	@Override
	public void startNewGame(String playerName, Difficulty difficulty) {
	    // Determina vite iniziali in base alla difficoltà
	    final int initialLives = switch (difficulty) {
	        case EASY -> 4;
	        case MEDIUM -> 3;
	        case HARD -> 2;
	    };

	    // Crea il giocatore con inventario e infezione
	    Inventory inventory = new InventoryImpl();
	    Infection infection = new InfectionImpl();
	    Player player = new PlayerImpl(1, playerName, initialLives, inventory, infection);

	    this.game = new GameImpl(difficulty); // Crea la partita con la difficoltà scelta
	    this.game.addPlayer(player); // Aggiunge un giocatore alla partita
	    this.game.setOnTick(this::notifyStatusTick); // Collega GameImpl al metodo notifyStatusTick del Model	    

	    // Carica la storia dal file JSON
	    try (InputStreamReader reader = new InputStreamReader(getClass().getResourceAsStream("/story_01.json"))) {
	        Gson gson = new Gson();
	        StoryOneDTO dto = gson.fromJson(reader, StoryOneDTO.class);

	        if (dto == null || dto.rooms == null || dto.rooms.isEmpty())
	            throw new IllegalStateException("JSON storia vuoto o non valido");

	        ((GameImpl) this.game).loadStoryFromDTO(dto);

	        if (this.game.getCurrentRoom() == null)
	            throw new IllegalStateException("Stanza iniziale non trovata (id=" + dto.startRoomId + ")"); 

	    } catch (IOException e) {
	        throw new RuntimeException("Errore nel caricamento della storia JSON: " + e.getMessage(), e);
	    } catch (NullPointerException e) {
	        throw new RuntimeException("File story_01.json non trovato nel classpath", e);
	    }

	    this.game.start(); // Avvia la partita

	    this.notifyRoomUpdated(); // Notifica la View che la stanza corrente è pronta
	    
	    // Test mostra popup messaggio
	    //this.game.addPendingMessage("Messaggio di test");
	}

	@Override
	public GameState getGameState() {
		return this.game.getGameState();
	}

	@Override
	public void setGameState(GameState state) {
		this.game.setGameState(state);
	}

	@Override
	public List<Player> getPlayers() {
	    return this.game.getPlayers();
	}	

	@Override
	public Player getPlayer(String playerName) {
	    return this.game.getPlayer(playerName);
	}
	
	@Override
	public Difficulty getDifficulty() {
		return this.game.getDifficulty();
	}

	@Override
	public Room getCurrentRoom() {
		return this.game.getCurrentRoom();
	}
	
	@Override
	public List<String> usePendingMessages() {
	    List<String> messages = this.game.usePendingMessages(); // Salva i messaggi
	    
	    // Notifica ogni messaggio alla View
	    for (String m : messages) {
	        if (m.equals(ViewTexts.LIFE_LOST_INFECTION_MSG)) {
	        	this.notifyModelessMessage(m); // Per perdita vita causa infezione
	        } else {
	        	this.notifyMessage(m); // Per tutti gli altri messaggi
	        }
	    }
	    
	    return messages;
	}
	
	@Override
	public void chooseByIndex(int index) {
	    if (this.game.getCurrentRoom() == null) {
	        throw new IllegalStateException("Errore: nessuna stanza corrente impostata. " +
	            "Assicurati che loadStoryFromDTO sia stato chiamato e che il gioco sia stato avviato.");
	    }		
		
	    Room currentRoom = this.game.getCurrentRoom(); // Recupera la stanza corrente dal gioco

	    // Filtra le scelte disponibili: quelle per cui isAvailable() è true
	    List<StoryChoice> availableChoices = currentRoom.getChoices()
	            .stream()
	            .filter(StoryChoice::isAvailable)
	            .toList();

	    // Controlla che l’indice ricevuto sia valido
	    if (index < 0 || index >= availableChoices.size()) {
	        throw new IllegalArgumentException("Indice di scelta non valido: " + index);
	    }

	    StoryChoice selectedChoice = availableChoices.get(index); // Recupera la scelta corrispondente all’indice
	    selectedChoice.apply(this.game); // Applica la scelta al gioco
	    this.notifyRoomUpdated(); // Notifica subito la View della nuova stanza
	    this.usePendingMessages(); // Notifica eventuali messaggi
	    
	    // Notifica se il giocatore cambia stato
	    Player player = this.game.getPlayers().get(0);
	    switch (player.getPlayerState()) {
	        case WINNER -> this.notifyVictory();
	        case GAME_OVER -> this.notifyGameOver();
	        default -> {} // Continua
	    }
	    
	    // Dopo l’applicazione il Model notificherà la View tramite i listener registrati
	}

	@Override
	public void saveGame(String path) {
		// Salva il gioco in formato binario tramite serializzazione Java
        try (ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream(path))) {
        	output.writeObject(this.game); // Scrive l'oggetto Game nel file
            //System.out.println("Partita salvata in formato binario.");
        } catch (IOException e) {
            System.err.println("Errore durante il salvataggio della partita: " + e.getMessage());
            e.printStackTrace();
        }
	}

	@Override
	public void loadGame(String path) {
		// Carica il gioco da un file binario serializzato
        try (ObjectInputStream input = new ObjectInputStream(new FileInputStream(path))) {
            this.game = (Game) input.readObject(); // Legge l'oggetto Game dal file
            this.game.afterLoad(); // Ricrea il timer dell'infezione dopo il caricamneto della partita.
            this.game.setOnTick(this::notifyStatusTick);
            this.notifyRoomUpdated(); // Notifica la View dello stato corrente
            //System.out.println("Partita caricata.");
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Errore durante il caricamento della partita: " + e.getMessage());
            e.printStackTrace();
        }
	}
	
	@Override
	public void addListener(ModelListener l) {
	    this.listeners.add(l);
	}

	@Override
	public void removeListener(ModelListener l) {
	    this.listeners.remove(l);
	}
	
	/**
	 * Notifica ai listener che la stanza corrente è cambiata.
	 * Prepara i dati in una forma "semplice" (Stringhe e Liste di Stringhe),
	 * così la View non ha bisogno di conoscere direttamente le classi del Model.
	 */
	private void notifyRoomUpdated() {
	    // Se il gioco non è ancora stato avviato, o non c'è una stanza corrente, esce senza fare nulla.
	    if (this.game == null || this.game.getCurrentRoom() == null) 
	    	return;
	    
	    Player player = this.game.getPlayers().get(0); // Recupera il giocatore (unico in questa versione)
	    Room room = this.game.getCurrentRoom();
	    String playerName = player.getName();
	    Difficulty difficulty = this.game.getDifficulty();
	    String description = room.getDescription();
	    
	    // Elenco delle descrizioni delle scelte disponibili.
	    // Stream per filtrare le scelte disponibili e mappare la descrizione in una List<String>.
	    java.util.List<String> choices = room.getChoices()
	    		.stream()
	            .filter(c -> c.isAvailable()) // Tiene solo le scelte disponibili
	            .map(c -> c.getDescription()) // Prende il testo descrittivo della scelta
	            .toList(); // Raccoglie il risultato in una lista
	    
	    int lives = player.getLives(); // Numero di vite attuali del giocatore
	    
	    // Elenco dei nomi degli oggetti nell’inventario.
	    // Stream per mappare ogni Item al suo nome.
	    java.util.List<String> inventory = player.getInventory().getItems()
	    		.stream()
	            .map(i -> i.getName())
	            .toList();
	    
	    String infectionLabel; // Testo che rappresenta lo stato dell’infezione
	    if (player.getInfection().isActive()) { // Se l’infezione è attiva, calcola i minuti e secondi rimanenti dal tempo in millisecondi	        // 
	        long remainingMs = player.getInfection().getRemainingTime();
	        long minutes = (remainingMs / 1000) / 60; // Converte in minuti
	        long seconds = (remainingMs / 1000) % 60; // Calcola i secondi restanti
	        infectionLabel = String.format("%02d:%02d", minutes, seconds); // Formattato mm:ss
	    } else { // Se l’infezione non è attiva mostra un placeholder
	        infectionLabel = "---";
	    }

	    // Notifica al listener
	    for (ModelListener l : listeners) {
	        l.onRoomUpdated(playerName, difficulty, description, choices, lives, inventory, infectionLabel);
	    }
	}
	
	/**
	 * Notifica ad ogni tick del timer infezione.
	 * Aggiorna solo vite e timer infezione, senza ricostruire la stanza.
	 */
	private void notifyStatusTick() {
	    if (this.game == null || this.game.getCurrentRoom() == null) 
	    	return;

	    Player player = this.game.getPlayers().get(0); // Recupera il player (unico in questa versione)

	    // Prepara label infezione
	    String infectionLabel;
	    if (player.getInfection().isActive()) {
	        long ms = player.getInfection().getRemainingTime();
	        long min = (ms / 1000) / 60;
	        long sec = (ms / 1000) % 60;
	        infectionLabel = String.format("%02d:%02d", min, sec);
	    } else {
	        infectionLabel = "---";
	    }

	    // Notifica tick
	    for (ModelListener l : listeners) {
	        l.onStatusTick(player.getLives(), infectionLabel);
	    }

	    // Mostra eventuali messaggi
	    for (String m : this.game.usePendingMessages()) {
	        this.notifyMessage(m);
	    }
	    
	    // Controlla vite per schermata sconfitta
	    if (player.getLives() <= 0 || player.getPlayerState() == PlayerState.GAME_OVER)
	        this.notifyGameOver();
	}	

	/**
	 * Notifica ai listener che il gioco è terminato con vittoria.
	 */
	private void notifyVictory() {
	    for (ModelListener l : listeners) {
	        l.onVictory(); // Invoca il callback su ogni listener
	    }
	}
	
	/**
	 * Notifica ai listener che il gioco è terminato con sconfitta (Game Over).
	 */
	private void notifyGameOver() {
	    for (ModelListener l : listeners) {
	        l.onGameOver(); // Invoca il callback su ogni listener
	    }
	}	

	/**
	 * Notifica ai listener un messaggio generico.
	 * Usato per comunicare eventi particolari (es. "Hai trovato un oggetto").
	 * 
	 * @param msg il testo del messaggio
	 */
	private void notifyMessage(String msg) {
	    for (ModelListener l : listeners) {
	        l.onMessage(msg); // Invoca il callback su ogni listener
	    }
	}

	/**
	 * Notifica ai listener un messaggio generico, con una finestra non modale (non bloccante).
	 * Usato per perdita vita causa infezione
	 *
	 * @param msg il testo del messaggio
	 */	
	private void notifyModelessMessage(String msg) {
	    for (ModelListener l : listeners) {
	        l.onModelessMessage(msg);
	    }
	}
	
}

// Non utilizzato in questa versione del gioco.
/*
@Override
public void restart() {
    if (this.game == null)
        throw new IllegalStateException("Nessuna partita da riavviare.");

    if (!this.game.hasPlayers())
        throw new IllegalStateException("Nessun giocatore presente nella partita attuale."); 
    
    String playerName = this.game.getPlayers().get(0).getName(); // Recupera il nome del giocatore (primo e unico in questa versione iniziale del gioco)

    Difficulty difficulty = this.game.getDifficulty(); // Recupera la difficoltà attuale
    this.startNewGame(playerName, difficulty); // Avvia una nuova partita con le stesse impostazioni
}
*/
