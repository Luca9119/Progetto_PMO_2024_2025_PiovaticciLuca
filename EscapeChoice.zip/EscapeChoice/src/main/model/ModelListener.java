package main.model;

import java.util.List;

import main.model.game.Difficulty;

/**
 * Interfaccia di ascolto per gli aggiornamenti del Model.
 * Implementata dalla View per ricevere notifiche dal Model,
 * senza che il Controller debba mai chiamare la View.
 */
public interface ModelListener {
	
    /**
     * Notifica che la stanza corrente è cambiata.
     *
     * @param description descrizione della stanza
     * @param choices lista delle scelte disponibili
     * @param lives numero di vite rimanenti del giocatore
     * @param inventory lista degli oggetti nell’inventario del giocatore
     * @param infectionLabel stato dell’infezione
     */
    void onRoomUpdated(String playerName, Difficulty difficulty, String description, List<String> choices, int lives, List<String> inventory, String infectionLabel);
    
    /**
     * Aggiorna vite e timer infezione ogni secondo.
     * 
     * @param lives il numero corrente di vite rimanenti del giocatore
     * @param infectionLabel testo formattato che rappresenta il tempo rimanente dell'infezione
     */
    void onStatusTick(int lives, String infectionLabel);    

    /**
     * Notifica che il gioco è terminato con vittoria.
     */
    void onVictory();

    /**
     * Notifica che il gioco è terminato con game over.
     */
    void onGameOver();    

    /**
     * Notifica un messaggio generico da mostrare all’utente.
     *
     * @param message testo del messaggio
     */
    void onMessage(String message);	
    
    /**
     * Notifica un messaggio con una finestra non modale (non bloccante) da mostrare all’utente.
     *
     * @param message testo del messaggio
     */    
    void onModelessMessage(String message);   

}
