package main.model.game;

/**
 * Enum che rappresenta i livelli di difficoltà della partita.
 */
public enum Difficulty {
	
	EASY, MEDIUM, HARD;
	
}
