package main.model.game;

import java.io.Serializable;
import java.util.List;

import main.model.player.Player;
import main.model.story.Room;

/**
 * Interfaccia che rappresenta lo stato globale del gioco.
 * Tiene traccia del giocatore, della scena attuale, della difficoltà e dello stato di gioco.
 */
public interface Game extends Serializable {

    /**
     * Aggiunge un giocatore alla partita.
     * 
     * @param player il giocatore da aggiungere alla partita
     */
    void addPlayer(Player player);  
    
    /**
     * Preleva da una Map i giocatori della partita,
     * (nella versione attuale è presente solo un giocatore),
     * e li restituisce.
     * 
     * @return List<Player> lista di Players
     */
    List<Player> getPlayers();
    
    /**
     * Restituisce il giocatore passato come parametro.
     * 
     * Può lanciare un'eccezione se il giocatore non è presente nella partita.
     * 
     * @param playerName il nome del giocatore da restituire
     * 
     * @return Player il giocatore se presente nella partita
     * 
     * @throws IllegalStateException se il giocatore non è presente
     */
    Player getPlayer(String playerName);
    
    /**
     * Verifica se la partita possiede giocatori.
     * 
     * @return true se è presente almeno un giocatore, false altrimenti
     */    
    boolean hasPlayers();

    /**
     * Restituisce la stanza corrente in cui si trova il giocatore.
     * 
     * @return Room la stanza corrente
     */
    Room getCurrentRoom();
    
    /**
     * Imposta la stanza corrente del gioco e applica eventuali effetti propri della stanza
     * (infezione, messaggi).
     * 
     * @param room la nuova stanza
     */
    void setCurrentRoom(Room room);

    /**
     * Restituisce il livello di difficoltà impostato per la partita.
     * 
     * @return un valore dell'enumerazione Difficulty
     */
    Difficulty getDifficulty();

    /**
     * Restituisce lo stato attuale della partita.
     * 
     * @return un valore dell'enumerazione GameState
     */
    GameState getGameState();
    
    /**
     * Imposta lo stato attuale della partita.
     * 
     * @param state lo stato da impostare
     */
    void setGameState(GameState state);
    
    /**
     * Inizializza e avvia una nuova partita.
     * Avvia il timer infezione da zero: 
     * è attivo ma non fa nulla se il giocatore non è infetto,
     * semplifica la logica e garantisce che esista sempre un solo timer attivo.
     * 
     * Può lanciare un'eccezione se la partita non possiede almeno un giocatore.
     * 
     * @throws IllegalStateException se la partita non possiede almeno un giocatore 
     */
    void start();
    
    /**
     * Aggiunge un messaggio alla lista dei messaggi pendenti.
     * 
     * I messaggi pendenti vengono usati per comunicare informazioni dalla logica di gioco
     * alla View e verranno usati successivamente.
     * 
     * @param message il testo del messaggio da aggiungere
     */    
    void addPendingMessage(String message);
    
    /**
     * Restituisce e svuota la lista dei messaggi pendenti.
     * 
     * Ogni chiamata restituisce una copia della lista di messaggi attuali,
     * e li rimuove dalla coda interna, in modo che non vengano mostrati più volte.
     * 
     * @return List<String> lista contenente i messaggi pendenti
     */    
    List<String> usePendingMessages(); 

    /**
     * Ricostruisce gli oggetti non transient (non serializzabili).
     * Ricrea e avvia il Timer dell’infezione.
     * Chiamato dopo un caricamento da file.
     */
    void afterLoad();
    
    /**
     * Imposta il callback che verrà eseguito ad ogni tick (1 secondo) del timer infezione.
     * 
     * @param onTick callback Runnable che viene invocato ad ogni tick
     */
    void setOnTick(Runnable onTick);
    
    /**
     * Rimuove un giocatore dalla partita.
     * 
     * NOTA: Questo metodo non è utilizzato nella versione attuale, 
     * ma è mantenuto per possibili implementazioni future.
     * 
     * @param player il giocatore da rimuovere dalla partita
     */
    //void removePlayer(Player player);

    /**
     * Restituisce lo stato dell'allarme.
     * 
     * NOTA: Questo metodo non è utilizzato nella versione attuale, 
     * ma è mantenuto per possibili implementazioni future.
     * 
     * @return lo stato dell'allarme come boolean
     */
    //boolean getAlarmState();
    
    /**
     * Imposta lo stato dell'allarme.
     * 
     * NOTA: Questo metodo non è utilizzato nella versione attuale, 
     * ma è mantenuto per possibili implementazioni future.
     * 
     * @param state lo stato dell'allarme da impostare
     */
    //void setAlarmState(boolean state);
}
