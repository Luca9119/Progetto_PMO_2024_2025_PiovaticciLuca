package main.model.game;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import java.util.stream.Collectors;

import main.model.player.Player;
import main.model.player.PlayerState;
import main.model.player.Item;
import main.model.player.ItemImpl;
import main.model.story.Room;
import main.model.story.RoomImpl;
import main.model.story.StoryChoiceImpl;
import main.view.ViewTexts;
import main.model.story.Enemy;
import main.model.story.EnemyImpl;

/**
 * Implementazione dell'interfaccia Game.
 */
public class GameImpl implements Game {

	/**
	 * Identificatore univoco di versione per la serializzazione dell'oggetto.
	 * Garantisce compatibilità tra versioni della classe salvate/caricate da file.
	 * Versione 1 serializzabile della classe.
	 */
	private static final long serialVersionUID = 1L;

	private static final long INFECTION_CHECK_TIME = 1000; // Controllo infezione in millisecondi (ogni 1 secondo)

	// Utilizzo di Map per possibili implementazioni future con più giocatori,
	// ma nella versione attuale il gioco prevede l'utilizzo di un giocatore.
	//private final Player player;
    private Map<String, Player> players;

    private final Difficulty difficulty;
    private Room currentRoom;
    private Map<Integer, Room> mapRooms = new HashMap<>();
    private GameState gameState;
    private final List<String> pendingMessages = new ArrayList<>(); // Lista dei messaggi che la View potrà leggere e mostrare

    /**
     * Timer contiene un thread TimerThread: non può essere serializzato perché dipende dallo stato del sistema operativo.
     */
    private transient Timer infectionTimer;
    
    /**
     * Callback da eseguire ad ogni tick (1 secondo) del timer infezione.
     * Non viene serializzata perché è callback (punta) verso la View (es. Swing Timer che aggiorna label vite e infezione):
     * la View non fa parte del dominio e non deve essere salvata,
     * viene ricreata quando si ricollega al Model dopo un caricamento.
     */
    private transient Runnable onTick; 

	// Utilizzo di alarmState in possibili implementazioni future.
    //private boolean alarmState;

    /**
     * Il costruttore accetta come parametro la difficoltà (difficulty).
     * I giocatori (players) sono aggiunti attraverso il metodo addPlayer.
     * 
     * @param difficulty la difficoltà impostata a inizio partita
     */
    public GameImpl(Difficulty difficulty) {
        this.players = new HashMap<>();
        this.difficulty = difficulty;
        this.currentRoom = null; // Impostato in setCurrentRoom
        this.gameState = GameState.OFF;
        this.infectionTimer = null; // Impostato in startInfectionTimer
    }

    // ------------------------------------------------------------
    // GESTIONE PLAYERS
    // ------------------------------------------------------------

    @Override
    public void addPlayer(Player player) {
        this.players.put(player.getName(), player);
    }   

    @Override
    public List<Player> getPlayers() {
        return this.players.values()
                .stream()
                .collect(Collectors.toList());
    }

    @Override
    public Player getPlayer(String playerName) {
        if (!this.players.containsKey(playerName))
            throw new IllegalStateException("Giocatore '" + playerName + "' non presente nella partita.");
        return this.players.get(playerName);
    } 

    @Override
    public boolean hasPlayers() {
        return !this.players.isEmpty();
    }

    // ------------------------------------------------------------
    // GESTION ROOMS
    // ------------------------------------------------------------

    @Override
    public Room getCurrentRoom() {
        return this.currentRoom;
    }

    @Override
    public void setCurrentRoom(Room room) {
        this.currentRoom = room;

        if (room != null) {
        	// Se la stanza ha l’infezione e il player non è ancora infetto, allora infetta il player
            if (room.getInfection() && !this.getPlayers().get(0).isInfected()) {
                this.getPlayers().get(0).infect();
                
                // Messaggio associato alla stanza
                if (room.getRoomMessage() != null)
                    this.addPendingMessage(room.getRoomMessage());
            }            
        }
    }

    // ------------------------------------------------------------
    // GESTIONE GAME
    // ------------------------------------------------------------

    @Override
    public Difficulty getDifficulty() {
        return this.difficulty;
    }

    @Override
    public GameState getGameState() {
        return this.gameState;
    }

    @Override
    public void setGameState(GameState state) {
        this.gameState = state;
    }

    @Override
    public void start() {
        if (!this.hasPlayers())
            throw new IllegalStateException("Impossibile avviare il gioco senza almeno un giocatore.");

        if (this.currentRoom == null) {
            throw new IllegalStateException("La stanza iniziale non è stata impostata.");
        }        
        
        this.gameState = GameState.ON; // Imposta lo stato di gioco su ON
        
        // Avvia il timer infezione da zero.
        // Il timer thread è attivo ma non fa nulla se il giocatore non è infetto 
        this.startInfectionTimer();
    }

    // ------------------------------------------------------------
    // MESSAGGI PENDENTI
    // ------------------------------------------------------------

    @Override
    public void addPendingMessage(String message) {
        this.pendingMessages.add(message);
    }

    @Override
    public List<String> usePendingMessages() {
        List<String> listPendingMessages = new ArrayList<>(this.pendingMessages); // Per evitare modifiche esterne alla lista
        this.pendingMessages.clear(); // Svuota la lista dopo aver usato i messaggi
        return listPendingMessages;
    }

    // ------------------------------------------------------------
    // TIMER INFEZIONE
    // ------------------------------------------------------------  
    
    /**
     * Crea e avvia il Timer infezione.
     * Schedula il controllo periodico chiedendo al Player di aggiornare l’infezione,
     * aggiornando anche il remainingTime (settato in InfectionImpl) per la GUI.
     * 
     * Il timer parte sempre all’avvio della partita, ma non riduce vite se il Player non è infetto.
     * Per implementazioni future con la presenza di un meccanismo di guarigione,
     * non serve fermare e ricreare il timer in caso di guarigione.
     * Questa scelta semplifica la logica e garantisce che esista sempre un solo timer attivo.
     * 
     * Dopo un caricamento (afterLoad) il timer viene ricreato,
     * e riprende dal remainingTime salvato.
     * Ad ogni tick (1 secondo) può notificare la View tramite onTick,
     * per aggiornare le label vite e infezione.
     */
    private void startInfectionTimer() {
        this.stopInfectionTimer(); // Ferma eventuale timer precedente
        
        this.infectionTimer = new Timer(); // Crea nuovo timer

        Player player = this.players.values().iterator().next(); // Recupera il player (unico nella versione attuale)

        // Avvia il timer per la gestione dell'infezione
        this.infectionTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
            	 // Ferma il timer se la partita non è attiva
                if (gameState != GameState.ON) {
                    this.cancel();
                    return;
                }

                // Aggiorna stato infezione
                if (player.isInfected()) {
                	int actualLives = player.getLives();
                	
                    player.updateInfectionTimer(); // -1 vita se il timer va a 0
                    
                    // Se l’infezione ha tolto vite, aggiunge messaggio
                    if (player.getLives() < actualLives && player.getLives() > 0) {
                        addPendingMessage(ViewTexts.LIFE_LOST_INFECTION_MSG);
                    }

                    // Se l’infezione ha causato il GAME_OVER
                    if (player.getLives() <= 0 && player.getLives() < actualLives) {
                        player.setPlayerState(PlayerState.GAME_OVER);
                        setGameState(GameState.OFF);
                        this.cancel();
                        addPendingMessage(ViewTexts.GAMEOVER_INFECTION_MSG);
                    }
                }

                // In caso di vittoria o game over, ferma il timer
                if (player.getPlayerState() == PlayerState.WINNER || player.getPlayerState() == PlayerState.GAME_OVER) {
                    setGameState(GameState.OFF);
                    this.cancel();
                }
                
                // Notifica tick al Model
                if (onTick != null) {
                    onTick.run();
                }             
            }
        }, 0, INFECTION_CHECK_TIME);
    }
    
	/**
	 * Ferma il Timer attuale, se avviato.
	 */
    private void stopInfectionTimer() {
        if (this.infectionTimer != null) {
            this.infectionTimer.cancel(); // Cancella il timer thread
            this.infectionTimer = null;   // Resetta infectionTimer
        }
    }

    @Override
    public void afterLoad() {        
        Player player = this.getPlayers().get(0);
        
        // Controlla se il player è infetto
        if (player.isInfected())
            player.getInfection().resumeTimerAfterLoad(); // Ripristina il timer dal remainingTime     
        
        this.startInfectionTimer(); // Ricrea il timer dell'infezione dopo il caricamneto
    }

    @Override
    public void setOnTick(Runnable onTick) {
        this.onTick = onTick;
    }
    
    // ------------------------------------------------------------
    // STORIA: RICOSTRUZIONE STANZE E SCELTE DAL DTO
    // ------------------------------------------------------------

    /**
     * Costruisce le stanze e le scelte a partire dalle classi DTO.
     *
     * @param dto oggetto principale della storia
     */
    public void loadStoryFromDTO(StoryOneDTO dto) {
    	// Mappa che contiene tutte le stanze della storia indicizzate per id.
    	// Utile per collegare rapidamente le scelte (choices) alla loro stanza di destinazione (targetRoom).    	
        // Map: KEY (Integer Id), VALUE (Room room)
    	this.mapRooms.clear(); // Reset mappa se già usata

        // Crea tutte le stanze con scelte ancora vuote
        for (RoomDTO r : dto.rooms) { // Itera ogni stanza definita nel JSON
            Enemy enemy = null;

            // Eventuale nemico definito dal JSON
            if (r.enemy != null) {
                String enemyName = r.enemy.name;
                int strength = r.enemy.strength;
                String requisiteItemName = r.enemy.requisiteItem;
                Item requisiteItem = new ItemImpl(requisiteItemName);
                enemy = new EnemyImpl(enemyName, strength, requisiteItem);
            }

            // Crea la stanza con la lista scelte vuota e l'eventuale nemico
            RoomImpl room = new RoomImpl(r.id, r.title, r.description, new ArrayList<>(), enemy, r.infection, r.roomMessage);

            this.mapRooms.put(r.id, room); // Aggiunge la stanza alla Map
        }

        // Crea le scelte (con le lambda per condizioni/effetti)
        for (RoomDTO roomDTO : dto.rooms) {
            RoomImpl currentRoom = (RoomImpl) this.mapRooms.get(roomDTO.id);  // Recupera la stanza corrente dalla Map

            for (ChoiceDTO c : roomDTO.choices) { // Itera ogni scelta definita nel JSON

            	// Crea le condizioni per la possibilità di selezionare le scelte          	
            	SerializableSupplier<Boolean> condition;
                switch (c.condition.type) {
                    case "always" -> condition = () -> true; // Sempre disponibile
                    case "has_item" -> condition = () -> this.getPlayers().get(0).hasItem(new ItemImpl(c.condition.item));
                	// In questa versione della narrazione, 
                    // la condizione 'not_has_item' non viene utilizzata.
                    case "not_has_item" -> condition = () -> !this.getPlayers().get(0).hasItem(new ItemImpl(c.condition.item));
                    default -> condition = () -> true;
                }

                // Lista degli effetti da applicare quando il giocatore fa determinate scelte
                List<SerializableConsumer<Game>> effects = new ArrayList<>();
                if (c.effects != null) { // Se nel JSON ci sono effetti associati
                    for (EffectDTO e : c.effects) {
                        switch (e.type) {
                        	// In questa versione della narrazione,
                        	// questo effetto non viene utilizzato come effetto diretto di una scelta.
                            case "add_item" -> effects.add(g -> {
                            	Player p = g.getPlayers().get(0);
                                p.addItem(new ItemImpl(e.item));
                                if ("medkit".equalsIgnoreCase(e.item))
                                    p.addLife();
                                if (e.failMessage != null)
                                    g.addPendingMessage(e.failMessage);
                            });
                        	// In questa versione della narrazione,
                        	// questo effetto non viene utilizzato come effetto diretto di una scelta.                           
                            case "lose_life" -> effects.add(g -> {
                            	Player p = g.getPlayers().get(0);
                            	p.loseLife();
                                if (e.effectMessage != null)
                                    g.addPendingMessage(e.effectMessage);
                                if (p.getLives() <= 0) {
                                    p.setPlayerState(PlayerState.GAME_OVER);
                                    g.setGameState(GameState.OFF);
                                }                            	
                            });
                        	// In questa versione della narrazione,
                        	// questo effetto non viene usato come effetto diretto di una scelta.                            
                            case "infect" -> effects.add(g -> { // Se l'infezione è causata dall'effetto di una scelta
                            	Player p = g.getPlayers().get(0);
                            	if (!p.isInfected()) {
                                    p.infect();
                                    if (e.effectMessage != null) {
                                        g.addPendingMessage(e.effectMessage);
                                    }
                                }
                            });
                            case "if_has_item" -> effects.add(g -> {
                            	Player p = g.getPlayers().get(0);
                                if (p.hasItem(new ItemImpl(e.item))) {
                                    // Successo se l'oggetto richiesto è presente nell'inventario
                                    if (e.successMessage != null)
                                        g.addPendingMessage(e.successMessage);                      	
                                    if (e.success != null) {
                                        if (e.success.equals("victory")) {
                                            // Caso codice per uscita
                                            p.setPlayerState(PlayerState.WINNER);
                                            g.setGameState(GameState.OFF);
                                        } else if (e.success.startsWith("goto_")) {
                                            // Caso generale: spostamento in una stanza specifica (secondo la narrazione story_01.json)
                                            int roomId = Integer.parseInt(e.success.replace("goto_", ""));
                                            Room target = this.mapRooms.get(roomId);
                                            g.setCurrentRoom(target);
                                        }
                                    }
                                } else {
                                    // Fallimento se manca l'oggetto richiesto
                                    if (e.fail != null) {
                                        switch (e.fail) {
                                            case "add_item" -> {
                                                p.addItem(new ItemImpl(e.item));
                                                if ("medkit".equalsIgnoreCase(e.item)) {
                                                    p.addLife();
                                                }
                                                if (e.failMessage != null) {
                                                    g.addPendingMessage(e.failMessage);
                                                }
                                            }                                          
                                            case "lose_life" -> {
                                                p.loseLife();
                                                if (e.failMessage != null)
                                                    g.addPendingMessage(e.failMessage);
                                                if (p.getLives() <= 0) {
                                                    p.setPlayerState(PlayerState.GAME_OVER);
                                                    g.setGameState(GameState.OFF);
                                                }
                                            }
                                            case "game_over" -> {
                                                if (e.failMessage != null)
                                                    g.addPendingMessage(e.failMessage);
                                                p.setPlayerState(PlayerState.GAME_OVER);
                                                g.setGameState(GameState.OFF);
                                            }
                                        }
                                    }
                                }
                            });
                        	// In questa versione della narrazione,
                        	// questo effetto non viene utilizzato come effetto diretto di una scelta.                           
                            case "game_over" -> effects.add(g -> {
                            	Player p = g.getPlayers().get(0);
                                if (e.effectMessage != null)
                                    g.addPendingMessage(e.effectMessage);
                                p.setPlayerState(PlayerState.GAME_OVER);
                                g.setGameState(GameState.OFF);
                            });
                        	// In questa versione della narrazione,
                        	// questo effetto non viene utilizzato come effetto diretto di una scelta.                           
                            case "winner" -> effects.add(g -> {
                            	Player p = g.getPlayers().get(0);
                                if (e.effectMessage != null)
                                    g.addPendingMessage(e.effectMessage);
                                p.setPlayerState(PlayerState.WINNER);
                                g.setGameState(GameState.OFF);
                            });
	                         // In questa versione della narrazione,
	                         // questo effetto non viene utilizzato come effetto diretto di una scelta.
	                         case "show_message" -> effects.add(g -> {
	                             if (e.effectMessage != null)
	                                 g.addPendingMessage(e.effectMessage);
	                         });                        
                            case "lose_life_random" -> effects.add(g -> {
                            	Player p = g.getPlayers().get(0);
                                Random random = new Random();
                                int randomLife = random.nextInt(2); // Genera 2 valori casuali nell'intervallo [0,1]
                                if (randomLife == 1) { // -1 vita
                                    p.loseLife();
                                    if (e.failMessage != null)
                                        g.addPendingMessage(e.failMessage);
                                    if (p.getLives() <= 0) {
                                        p.setPlayerState(PlayerState.GAME_OVER);
                                        g.setGameState(GameState.OFF);
                                    }
                                } else {
                                    if (e.successMessage != null)
                                        g.addPendingMessage(e.successMessage);
                                }
                            });
                            case "attack_enemy" -> effects.add(g -> {
                                Room current = g.getCurrentRoom();
                                if (current.hasEnemy()) {
                                    Enemy enemy = current.getEnemy();
                                    Player p = g.getPlayers().get(0);
                                    boolean survived = enemy.attack(p);
                                    if (!survived) {
                                        if (e.failMessage != null)
                                            g.addPendingMessage(e.failMessage);
                                        p.setPlayerState(PlayerState.GAME_OVER);
                                        g.setGameState(GameState.OFF);
                                    } else {
                                        if (p.getLives() <= 0) { // Caso con arma ma 1 vita residua
                                            p.setPlayerState(PlayerState.GAME_OVER);
                                            g.setGameState(GameState.OFF);
                                        }
                                        if (e.successMessage != null)
                                            g.addPendingMessage(e.successMessage);
                                    }
                                }
                            });                            
                            default -> {} // Ignora tipi sconosciuti
                        }
                    }
                }

                Room targetRoom = this.mapRooms.get(c.targetRoomId); // Stanza di destinazione
                
                // Crea la scelta
                StoryChoiceImpl choice = new StoryChoiceImpl(
                	c.id,
                    c.text,
                    targetRoom,
	            	condition,
                    effects
                );
                
                currentRoom.addChoice(choice);  // Aggiunge la scelta alla stanza corrente
            }
        }
        
        // Imposta la stanza corrente in base allo startRoomId definito nel DTO
        Room startRoom = this.mapRooms.get(dto.startRoomId);
        if (startRoom == null) {
            throw new IllegalStateException("StartRoomId non valido: " + dto.startRoomId);
        }
        this.setCurrentRoom(startRoom);
    }
    
    // Non utilizzato nella versione attuale
    /*
    @Override
    public void removePlayer(Player player) {
    	this.players.remove(player.getName());
    }
    */ 

    // Non utilizzato nella versione attuale
    /*
    @Override
    public boolean getAlarmState() {
    	return this.alarmState;
    }
    */

    // Non utilizzato nella versione attuale
    /*
    @Override
    public void setAlarmState(boolean state) {
    	this.alarmState = state;
    }
    */       
}

 
