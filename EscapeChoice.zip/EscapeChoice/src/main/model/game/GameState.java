package main.model.game;

/**
 * Enum che rappresenta lo stato attuale della partita.
 * 
 * NOTA: lo stato PAUSE non è utilizzato nella versione attuale, 
 * ma è mantenuto per possibili implementazioni future che prevedono un menu grafico,
 * per impostare lo stato della partita in corso.
 */
public enum GameState {
	
    ON, OFF, PAUSE;
    
}
