package main.model.game;

import java.io.Serializable;
import java.util.function.Consumer;

/**
 * Variante serializzabile dell'interfaccia funzionale Consumer.
 * 
 * Permette di definire azioni (effetti) che accettano un parametro di tipo T e non restituiscono nulla.
 * 
 * Essendo serializzabile, può essere usata in contesti in cui gli oggetti devono essere salvati su file,
 * o trasferiti in rete.
 * 
 * Può essere usata direttamente con espressioni lambda o method reference (perché @FunctionalInterface).
 *
 * @param <T> il tipo dell’argomento accettato dal consumer
 */
@FunctionalInterface
public interface SerializableConsumer<T> extends Consumer<T>, Serializable {
    // Non sono necessari metodi aggiuntivi.
    // L'interfaccia eredita il metodo astratto accept(T t) da Consumer.
}
