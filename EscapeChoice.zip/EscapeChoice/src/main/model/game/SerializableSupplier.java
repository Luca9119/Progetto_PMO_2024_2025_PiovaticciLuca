package main.model.game;

import java.io.Serializable;
import java.util.function.Supplier;

/**
 * Variante serializzabile dell'interfaccia funzionale Supplier.
 * 
 * Rappresenta un fornitore di valori: non accetta parametri e restituisce un risultato di tipo T.
 * 
 * Essendo serializzabile, può essere usata in contesti in cui gli oggetti devono essere salvati su file,
 * o trasferiti in rete.
 * 
 * Può essere usata direttamente con espressioni lambda o method reference (perché @FunctionalInterface).
 *
 * @param <T> il tipo del valore restituito dal supplier
 */
@FunctionalInterface
public interface SerializableSupplier<T> extends Supplier<T>, Serializable {
    // Non sono necessari metodi aggiuntivi.
    // L'interfaccia eredita il metodo astratto get() da Supplier.
}
