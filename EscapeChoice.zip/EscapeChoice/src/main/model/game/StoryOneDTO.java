package main.model.game;

import java.io.Serializable;
import java.util.List;

/**
 * Classi di appoggio DTO (Data Transfer Object),
 * utilizzate per fare il parsing (deserializzazione) del file JSON con Gson.
 * Queste classi servono per leggere i dati dal JSON e trasformarli in oggetti del dominio (RoomImpl, StoryChoiceImpl, ecc.).
 * Non contengono logica di gioco.
 */

/**
 * Classe pubblica principale
 */
public class StoryOneDTO implements Serializable {

	/**
	 * Identificatore univoco di versione per la serializzazione dell'oggetto.
	 * Garantisce compatibilità tra versioni della classe salvate/caricate da file.
	 * Versione 1 serializzabile della classe.
	 */
	private static final long serialVersionUID = 1L;
	
	public int startRoomId;        // ID della stanza iniziale
    public List<RoomDTO> rooms;    // Lista di stanze nella storia
}


/**
 * Classi package-private (Gson le può istanziare)
 */

/**
 * Rappresenta una stanza dal JSON
 */
class RoomDTO implements Serializable {
	
	/**
	 * Identificatore univoco di versione per la serializzazione dell'oggetto.
	 * Garantisce compatibilità tra versioni della classe salvate/caricate da file.
	 * Versione 1 serializzabile della classe.
	 */
	private static final long serialVersionUID = 1L;
	
    public int id;                  // ID univoco della stanza
    public String title;            // Titolo della stanza
    public String description;      // Descrizione testuale
    public EnemyDTO enemy;          // Eventuale nemico (di default null se assente)
    public boolean infection;		// Eventuale infezione (di default false se assente)
    public List<ChoiceDTO> choices; // Scelte disponibili
    public String roomMessage;		// Eventuali messaggi (di default null se assente)
}

/**
 * Rappresenta una scelta dal JSON
 */
class ChoiceDTO implements Serializable {

	/**
	 * Identificatore univoco di versione per la serializzazione dell'oggetto.
	 * Garantisce compatibilità tra versioni della classe salvate/caricate da file.
	 * Versione 1 serializzabile della classe.
	 */
	private static final long serialVersionUID = 1L;
	
    public int id;                   // ID univoco della scelta
    public String text;              // Testo mostrato al giocatore
    public int targetRoomId;         // ID stanza di destinazione
    public ConditionDTO condition;   // Condizione per essere disponibile
    public List<EffectDTO> effects;  // Effetti applicati quando selezionata
}

/**
 * Rappresenta un nemico
 */
class EnemyDTO implements Serializable {
	
	/**
	 * Identificatore univoco di versione per la serializzazione dell'oggetto.
	 * Garantisce compatibilità tra versioni della classe salvate/caricate da file.
	 * Versione 1 serializzabile della classe.
	 */
	private static final long serialVersionUID = 1L;
	
    public String name;          // Nome del nemico
    public int strength;         // Forza del nemico
    public String requisiteItem; // Oggetto richiesto
}

/**
 * Rappresenta la condizione di una scelta
 */
class ConditionDTO implements Serializable {
	
	/**
	 * Identificatore univoco di versione per la serializzazione dell'oggetto.
	 * Garantisce compatibilità tra versioni della classe salvate/caricate da file.
	 * Versione 1 serializzabile della classe.
	 */
	private static final long serialVersionUID = 1L;
	
    public String type; // Tipo di condizione ("always", "has_item", ecc.)
    public String item; // Oggetto richiesto (se serve)
}

/**
 * Rappresenta un effetto di una scelta
 */
class EffectDTO implements Serializable {

	/**
	 * Identificatore univoco di versione per la serializzazione dell'oggetto.
	 * Garantisce compatibilità tra versioni della classe salvate/caricate da file.
	 * Versione 1 serializzabile della classe.
	 */
	private static final long serialVersionUID = 1L;
	
	public String type;                 // Tipo di effetto ("add_item", "lose_life", "infect" ecc.)
    public String item;                 // Oggetto coinvolto (se serve)
    public String effectMessage;        // Per effetti semplici
    public String successMessage;       // Per effetti condizionali: se l’azione riesce (if_has_item, lose_life_random...)
    public String failMessage;          // Per effetti condizionali: se l’azione fallisce (if_has_item, lose_life_random...)
    public String success;              // Esito positivo (per if_has_item)
    public String fail;                 // Esito negativo (per if_has_item)
}
