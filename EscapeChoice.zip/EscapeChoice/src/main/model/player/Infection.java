package main.model.player;

import java.io.Serializable;

/**
 * Interfaccia che rappresenta lo stato di infezione del giocatore.
 * Quando l'infezione è attiva, il giocatore perde 1 vita ogni X minuti.
 */
public interface Infection extends Serializable {
	
    /**
     * Attiva lo stato di infezione.
     * Dopo l'attivazione, il giocatore inizierà a perdere vite nel tempo.
     */
    void activate();

    /**
     * Indica se il giocatore è attualmente infetto.
     * 
     * @return true se l'infezione è attiva, false altrimenti
     */
    boolean isActive();

    /**
     * Metodo da chiamare periodicamente o ad ogni scena.
     * Controlla se è il momento di perdere una vita.
     * 
     * @return true se il giocatore deve perdere una vita, false altrimenti
     */
    boolean checkLoseLife();
    
	/**
	 * Restituisce il tempo rimanente (in millisecondi) prima della prossima vita persa (utilizzato per la GUI).
	 * 
	 * @return -1 se non infetto o tempo rimanente in ms come long
	 */    
    long getRemainingTime();
    
    /**
     * Imposta il tempo residuo (dopo caricamento della partita).
     * 
     * @param remainingTime tempo residuo in millisecondi
     */    
    void resumeTimerAfterLoad();

}
