package main.model.player;

/**
 * Implementazione dell'interfaccia Infection.
 */
public class InfectionImpl implements Infection {

	/**
	 * Identificatore univoco di versione per la serializzazione dell'oggetto.
	 * Garantisce compatibilità tra versioni della classe salvate/caricate da file.
	 * Versione 1 serializzabile della classe.
	 */
	private static final long serialVersionUID = 1L;
	
	// Tempo necessario per perdere 1 vita
    private static final long DEFAULT_TIME_TO_LOSE_LIFE = 180000; // 3 minuti in millisecondi: 3 * 60 * 1000
    private long timeToLoseLife; // Tempo configurabile

    private boolean active;
    private long startTime; // Tempo iniziale
    private long remainingTime; // Tempo residuo in millisecondi alla prossima vita persa
    
    /**
     * Costruttore standard: usa DEFAULT_TIME_TO_LOSE_LIFE.
     */
    public InfectionImpl() {
        this(DEFAULT_TIME_TO_LOSE_LIFE);
    }
    
    /**
     * Costruttore con tempo configurabile (utile per i test).
     * 
     * @param timeToLoseLife tempo in ms necessario per perdere 1 vita
     */    
    public InfectionImpl(long timeToLoseLife) {
		this.active = false;
		this.startTime = 0;
		this.timeToLoseLife = timeToLoseLife;
		this.remainingTime = this.timeToLoseLife;
    }    

	@Override
	public void activate() {
        if (!this.active) {
            this.active = true;
            this.startTime = System.currentTimeMillis(); // Tempo in cui parte il timer
        }
	}

	@Override
	public boolean isActive() {
		return this.active;
	}

	@Override
	public boolean checkLoseLife() {
        if (!this.active) {
            return false;
        }

        long currentTime = System.currentTimeMillis();
        long timeElapsed = currentTime - this.startTime;
        
        // Aggiorna il tempo residuo ad ogni controllo dell'infezione.
        // Prende il valore massimo tra i due parametri: questo evita valori negativi.
        this.remainingTime = Math.max(0, this.timeToLoseLife - timeElapsed); 
        
        if (timeElapsed >= this.timeToLoseLife) {
            // Reset timer: - 1 vita
            this.startTime = currentTime;
            this.remainingTime = this.timeToLoseLife; // Ricomincia un nuovo ciclo
            return true;
        }

        return false;
	}

	@Override
	public long getRemainingTime() {
	    if (!this.active) 
	    	return -1;
	    
	    return this.remainingTime;
	}
	
    public void resumeTimerAfterLoad() {
    	// Il timer parte nel punto giusto
        this.startTime = System.currentTimeMillis() - (this.timeToLoseLife - this.remainingTime);
    }

}
