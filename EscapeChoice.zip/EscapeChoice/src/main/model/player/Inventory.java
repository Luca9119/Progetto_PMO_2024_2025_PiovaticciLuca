package main.model.player;

import java.io.Serializable;
import java.util.List;

/**
 * Interfaccia che rappresenta l'inventario del giocatore.
 * Contiene gli oggetti raccolti durante la partita.
 */
public interface Inventory extends Serializable {
	
    /**
     * Restituisce tutti gli oggetti attualmente presenti nell'inventario.
     * 
     * @return List<Item> lista contenente gli oggetti
     */
    List<Item> getItems();

    /**
     * Aggiunge un oggetto all'inventario.
     * 
     * @param item l'oggetto da aggiungere
     */
    void addItem(Item item);

    /**
     * Verifica se un oggetto è presente nell'inventario.
     * 
     * @param item oggetto da cercare
     * 
     * @return true se presente, false altrimenti
     */
    boolean hasItem(Item item);
    
    /**
     * Rimuove un oggetto dall'inventario.
     * 
     * NOTA: Questo metodo non è utilizzato nella versione attuale, 
     * ma è mantenuto per possibili implementazioni future.
     * 
     * @param item l'oggetto da rimuovere
     */    
    //void removeItem(Item item);	

}
