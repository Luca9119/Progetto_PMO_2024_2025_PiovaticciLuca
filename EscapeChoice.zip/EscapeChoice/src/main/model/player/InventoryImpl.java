package main.model.player;

import java.util.ArrayList;
import java.util.List;

/**
 * Implementazione dell'interfaccia Inventory.
 */
public class InventoryImpl implements Inventory {
	
	/**
	 * Identificatore univoco di versione per la serializzazione dell'oggetto.
	 * Garantisce compatibilità tra versioni della classe salvate/caricate da file.
	 * Versione 1 serializzabile della classe.
	 */
	private static final long serialVersionUID = 1L;
	
	private final List<Item> inventoryItems; // Contiene gli oggetti raccolti durante la partita
	
	public InventoryImpl() {
		this.inventoryItems = new ArrayList<>();
	}

	@Override
	public List<Item> getItems() {
		return this.inventoryItems;
	}

	@Override
	public void addItem(Item item) {
		this.inventoryItems.add(item);
	}

	@Override
	public boolean hasItem(Item item) {
		return this.inventoryItems.contains(item);
	}

	// Non utilizzato nella versione attuale
	/*
	@Override
	public void removeItem(Item item) {
		this.inventoryItems.remove(item);
	}
	*/

}
