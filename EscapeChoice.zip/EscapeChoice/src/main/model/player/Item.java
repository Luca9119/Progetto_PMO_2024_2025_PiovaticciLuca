package main.model.player;

import java.io.Serializable;

/**
 * Interfaccia che rappresenta un oggetto raccoglibile nel gioco.
 * Gli oggetti possono influenzare l'esito delle scelte o dei combattimenti.
 */
public interface Item extends Serializable {
	
    /**
     * Restituisce il nome dell'oggetto.
     * 
     * @return il nome dell'oggetto come String
     */
    String getName();
    
    /**
     * Applica l'effetto dell'oggetto quando viene utilizzato.
     * 
     * NOTA: Questo metodo non è utilizzato nella versione attuale, 
     * ma è mantenuto per possibili implementazioni future.
     *
     * @param player il giocatore che utilizza l'oggetto
     * @param game l'istanza corrente del gioco
     */    
    //void use(Player player, Game game);    
    
}
