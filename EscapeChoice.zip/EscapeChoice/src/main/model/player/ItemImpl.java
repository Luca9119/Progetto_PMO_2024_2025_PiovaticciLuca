package main.model.player;

import java.util.Objects;

/**
 * Implementazione dell'interfaccia Item.
 * 
 * NOTA: in future implementazioni,
 * la classe ItemImpl sarà estesa da altre che rappresenteranno diversi tipi di oggetti.
 * Nella versione attuale non sarà estesa e rappresenterà ogni tipo di oggetto.
 */
public class ItemImpl implements Item {

	/**
	 * Identificatore univoco di versione per la serializzazione dell'oggetto.
	 * Garantisce compatibilità tra versioni della classe salvate/caricate da file.
	 * Versione 1 serializzabile della classe.
	 */
	private static final long serialVersionUID = 1L;
	
	private final String name;
	
	public ItemImpl(String name) {
		this.name = name;
	}

	@Override
	public String getName() {
		return this.name;
	}
	
    /**
     * Due Item sono considerati uguali se hanno lo stesso nome.
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) 
        	return true;
        
        if (!(obj instanceof Item)) 
        	return false;
        
        Item otherItem = (Item) obj;
        return Objects.equals(this.name, otherItem.getName());
    }
    
    /**
     * Calcola un valore hash per l'oggetto Item, in coerenza con equals(Object obj).
     */
    @Override
    public int hashCode() {
        return Objects.hash(this.name);
    }

    /**
     * String del nome dell'oggetto Item.
     */
    @Override
    public String toString() {
        return "Item[" + this.name + "]";
    }

	// Non utilizzato nella versione attuale
	/*
	@Override
	public void use(Player player, Game game) {}
	*/

}
