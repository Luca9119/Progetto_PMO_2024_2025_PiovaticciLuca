package main.model.player;

//import main.model.game.Game;

/**
 * Rappresenta l'oggetto Medkit raccoglibile nel gioco.
 * 
 * Estende ItemImpl e ridefinisce il comportamento del metodo use():
 * quando viene utilizzato, aggiunge una vita al giocatore, fino a un massimo di 6 vite.
 * 
 * NOTA: Questa classe non è utilizzata nella versione attuale,
 * ma è mantenuta per possibili implementazioni future.
 */
public class Medkit extends ItemImpl {

	/**
	 * Identificatore univoco di versione per la serializzazione dell'oggetto.
	 * Garantisce compatibilità tra versioni della classe salvate/caricate da file.
	 * Versione 1 serializzabile della classe.
	 */
	private static final long serialVersionUID = 1L;
	
    public Medkit() {
        super("Medkit");
    }
    
    /**
     * Usa il Medkit sul giocatore.
     * Aggiunge una vita, fino a un massimo di 6.
     * 
     * @param player il giocatore che utilizza il Medkit
     * @param game l'istanza corrente del gioco
     */
    /*
    @Override
    public void use(Player player, Game game) {
    	if(player.getLives() < 6) { // Numero max vite = 6
            player.addLife();
            game.addPendingMessage("Hai usato un kit medico: guadagni 1 vita!");    		
    	} else {
    		game.addPendingMessage("Hai già raggiunto il numero massimo (6) di vite");
    	}
    }
    */

}
