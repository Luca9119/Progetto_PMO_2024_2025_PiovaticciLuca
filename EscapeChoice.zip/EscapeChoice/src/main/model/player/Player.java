package main.model.player;

import java.io.Serializable;

/**
 * Interfaccia che rappresenta il giocatore del gioco Escape Choice.
 * Il Player ha un numero limitato di vite, un inventario, e può essere infettato.
 */
public interface Player extends Serializable {
	
    /**
     * Restituisce l'id del giocatore.
     * 
     * @return Id del giocatore come int
     */
	int getId();
	
    /**
     * Restituisce il nome del giocatore.
     * 
     * @return il nome del giocatore come String
     */
	String getName();
	
    /**
     * Restituisce lo stato corrente del giocatore.
     * 
     * @return un valore dell'enumerazione PlayerState
     */
	PlayerState getPlayerState();
    
    /**
     * Imposta lo stato corrente del giocatore.
     * 
     * @param state lo stato da impostare
     */
    void setPlayerState(PlayerState state);
	
    /**
     * Restituisce il numero attuale di vite del giocatore.
     * 
     * @return vite rimanenti come int
     */
    int getLives();
    
    /**
     * Incrementa di una unità le vite del giocatore.
     * Numero massimo di vite: 6.
     */
    void addLife();    

    /**
     * Riduce di una unità le vite del giocatore.
     * Se le vite arrivano a zero, la partita termina.
     */
    void loseLife();

    /**
     * Restituisce l'inventario associato al giocatore.
     * 
     * @return Inventory l'inventario del giocatore
     */
    Inventory getInventory();

    /**
     * Aggiunge un oggetto all'inventario del giocatore.
     * 
     * @param item l'oggetto da raccogliere
     */
    void addItem(Item item);

    /**
     * Verifica se il giocatore possiede un determinato oggetto nell'inventario.
     * 
     * @param item l'oggetto da cercare
     * 
     * @return true se è presente nell'inventario, false altrimenti
     */
    boolean hasItem(Item item);
    
    /**
     * Restituisce l'infezione associata al giocatore.
     * 
     * @return Infection l'infezione del giocatore
     */    
    Infection getInfection();

    /**
     * Attiva lo stato di infezione del giocatore.
     * Dopo l'attivazione, il giocatore inizierà a perdere vite periodicamente.
     */
    void infect();

    /**
     * Verifica se il giocatore è attualmente infetto.
     * 
     * @return true se infetto, false altrimenti
     */
    boolean isInfected();

    /**
     * Aggiorna lo stato dell'infezione, e se necessario riduce le vite.
     * Va chiamato periodicamente o al cambio scena.
     */
    void updateInfectionTimer();
    
    /**
     * Usa un determinato oggetto se presente nell'inventario del giocatore.
     * Dopo l'utilizzo viene rimosso dall'inventario.
     * 
     * NOTA: Questo metodo non è utilizzato nella versione attuale, 
     * ma è mantenuto per possibili implementazioni future.
     * 
     * @param item l'oggetto da cercare
     * @param game l'istanza corrente del gioco (per applicare gli effetti derivanti dall'uso dell'oggetto)
     * 
     * @return true se l'oggetto è stato usato con successo, false se non era presente nell'inventario
     */
    //boolean useItem(Item item, Game game);

}
