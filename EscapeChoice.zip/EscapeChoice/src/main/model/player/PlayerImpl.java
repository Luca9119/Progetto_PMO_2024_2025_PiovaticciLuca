package main.model.player;

/**
 * Implementazione dell'interfaccia Player.
 */
public class PlayerImpl implements Player {
	
	/**
	 * Identificatore univoco di versione per la serializzazione dell'oggetto.
	 * Garantisce compatibilità tra versioni della classe salvate/caricate da file.
	 * Versione 1 serializzabile della classe.
	 */
	private static final long serialVersionUID = 1L;

	private int id;
	private String name;
	private PlayerState playerState;
	private int lives;
    private Inventory inventory;
    private Infection infection;
	
	public PlayerImpl(int id, String name, int initialLives, Inventory inventory, Infection infection) { 
		this.id = id;
		this.name = name;
		this.playerState = PlayerState.IS_PLAYING; // Stato iniziale del giocatore
		this.lives = initialLives;
		this.inventory = inventory;
		this.infection = infection;
	}
	
	@Override
	public int getId() {
		return this.id;
	}	

	@Override
	public String getName() {
		return this.name;
	}
	
	@Override
	public PlayerState getPlayerState() {
		return this.playerState;
	}
	
	@Override
	public void setPlayerState(PlayerState state) {
		this.playerState = state;
	}

	@Override
	public int getLives() {
		return this.lives;
	}
	
	@Override
	public void addLife() {
		if(this.lives < 6)
			this.lives++;
	}	

	@Override
	public void loseLife() {
		if(this.lives > 0)
			this.lives--;
	}

	@Override
	public Inventory getInventory() {
		return this.inventory;
	}

	@Override
	public void addItem(Item item) {
		this.inventory.addItem(item);
	}

	@Override
	public boolean hasItem(Item item) {
		return this.inventory.hasItem(item);
	}
	
	@Override
	public Infection getInfection() {
		return this.infection;
	}	

	@Override
	public void infect() {
		this.infection.activate();
	}

	@Override
	public boolean isInfected() {
		return this.infection.isActive();
	}

	@Override
	public void updateInfectionTimer() {
        if (this.infection.checkLoseLife())
        	this.loseLife();
	}

    @Override
    public String toString() {
        return "Player[" + this.name + "]";
    }
	
	// Non utilizzato nella versione attuale
	/*
	@Override
	public boolean useItem(Item item, Game game) {
	    if (this.hasItem(item)) {
	        this.inventory.removeItem(item);
	        item.use(this, game);
	        return true;
	    } else {
	        game.addPendingMessage("❌ Non hai questo oggetto nell'inventario!");
	        return false;
	    }
	}
	*/ 
	
	/**
	 * Due Player sono considerati uguali se hanno lo stesso nome.
	 * 
     * NOTA: Questo metodo non è utilizzato nella versione attuale, 
     * ma è mantenuto per possibili implementazioni future con più giocatori.
     */
	/*
    @Override
    public boolean equals(Object obj) {
        if (this == obj) 
        	return true;
        
        if (!(obj instanceof Player)) 
        	return false;
        
        Player otherPlayer = (Player) obj;
        return Objects.equals(this.name, otherPlayer.getName());
    }
    */
	
	/**
	 * Calcola un valore hash per l'oggetto Player, in coerenza con equals(Object obj).
	 * 
     * NOTA: Questo metodo non è utilizzato nella versione attuale, 
     * ma è mantenuto per possibili implementazioni future con più giocatori.
	 */
	/*
    @Override
    public int hashCode() {
        return Objects.hash(this.name);
    }
    */	

}
