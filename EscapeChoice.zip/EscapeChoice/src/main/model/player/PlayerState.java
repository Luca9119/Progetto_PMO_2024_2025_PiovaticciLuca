package main.model.player;

/**
 * Enum che rappresenta lo stato attuale del giocatore.
 */
public enum PlayerState {
	
	IS_PLAYING, WINNER, GAME_OVER;

}
