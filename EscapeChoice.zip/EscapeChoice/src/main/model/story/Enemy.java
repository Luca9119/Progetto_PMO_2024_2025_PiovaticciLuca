package main.model.story;

import java.io.Serializable;

import main.model.player.Player;

/**
 * Interfaccia che rappresenta un nemico presente in una scena.
 * Il combattimento può avere esito positivo o negativo,
 * a seconda della presenza di oggetti o della logica di gioco.
 */
public interface Enemy extends Serializable {
	
    /**
     * Restituisce il nome del nemico.
     * 
     * @return il nome dell'oggetto come String
     */
	String getName();
	
    /**
     * Restituisce la forza del nemico.
     * 
     * @return la forza del nemico come int
     */
	int getStrength();
	
    /**
     * Simula l'attacco del nemico.
     * 
     * @param player il giocatore che combatte contro il nemico
     * 
     * @return true se il giocatore sopravvive, false se perde una vita o la partita
     */
    boolean attack(Player player);

    /**
     * Restituisce l'arma necessaria per difendersi dal nemico.
     * 
     * NOTA: Questo metodo non è utilizzato nella versione attuale, 
     * ma è mantenuto per possibili implementazioni future.
     * 
     * @return Item l'arma necessaria
     */    
    //Item getRequisiteItem();

}
