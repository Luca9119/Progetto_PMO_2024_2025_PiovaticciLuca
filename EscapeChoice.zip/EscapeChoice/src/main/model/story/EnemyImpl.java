package main.model.story;

import java.util.Objects;

import main.model.player.Item;
import main.model.player.Player;
import main.model.player.PlayerState;

/**
 * Implementazione dell'interfaccia Enemy.
 */
public class EnemyImpl implements Enemy {

	/**
	 * Identificatore univoco di versione per la serializzazione dell'oggetto.
	 * Garantisce compatibilità tra versioni della classe salvate/caricate da file.
	 * Versione 1 serializzabile della classe.
	 */
	private static final long serialVersionUID = 1L;
	
	private final String name;
	private final int strength;
	private final Item requisiteItem; // Item (arma) necessaria per difendersi dal nemico
	
	public EnemyImpl(String name, int strength, Item item) {
		this.name = name;
		this.strength = strength;
		this.requisiteItem = item;
	}

	@Override
	public String getName() {
		return this.name;
	}

	@Override
	public int getStrength() {
		return this.strength;
	}

	@Override
	public boolean attack(Player player) {
	    if (this.strength == 1) { // Un solo nemico
	        if (player.hasItem(this.requisiteItem)) {
	            return true; // Sopravvive senza perdere vite
	        } else {
	        	player.loseLife(); // Perde 1 vita
	            return player.getLives() > 0; // Sopravvive solo se ha ancora vite
	        }
	    }
	    else { // Due o più nemici
	        if (player.hasItem(this.requisiteItem)) {
	        	player.loseLife(); // Perde 1 vita
	            return true;
	        } else {
	        	player.setPlayerState(PlayerState.GAME_OVER); // Game over diretto
	            return false;
	        }
	    }
	}

    /**
     * Due Enemy sono considerati uguali se hanno lo stesso nome.
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) 
        	return true;
        
        if (!(obj instanceof Enemy)) 
        	return false;
        
        Enemy otherEnemy = (Enemy) obj;
        //return Objects.equals(this.name, otherEnemy.getName()) && Objects.equals(this.requisiteItem, otherEnemy.requisiteItem);
        return Objects.equals(this.name, otherEnemy.getName());
    }

    /**
     * Calcola un valore hash per l'oggetto Enemy, in coerenza con equals(Object obj).
     */    
    @Override
    public int hashCode() {
        return Objects.hash(this.name);
    }
    
    @Override
    public String toString() {
        return "Enemy[" + this.name + "]";
    }
    
    // Non utilizzato nella versione attuale
    /*
    @Override
    public Item getRequisiteItem() {
    	return this.requisiteItem;
    }
    */    

}
