package main.model.story;

import java.io.Serializable;
import java.util.List;

/**
 * Interfaccia che rappresenta una stanza (o scena) del gioco.
 * Ogni Room ha una descrizione, una lista di scelte
 * e in alcuni casi un pericolo (nemico o aria infetta).
 */
public interface Room extends Serializable {
	
    /**
     * Restituisce l'Id dell'oggetto.
     * 
     * @return l'Id dell'oggetto come int
     */
	int getId();
	
    /**
     * Restituisce il titolo testuale della stanza.
     * 
     * @return il titolo come String
     */
    String getTitle();	
	
    /**
     * Restituisce la descrizione testuale della stanza.
     * 
     * @return il testo descrittivo come String
     */
    String getDescription();

    /**
     * Aggiunge una scelta alla stanza.
     * 
     * @param choice la scelta da aggiungere alla stanza
     */
    void addChoice(StoryChoice choice);
    
    /**
     * Restituisce l'elenco delle scelte disponibili (eventualmente aggiornate) nella stanza.
     * 
     * @return List<StoryChoice> lista contenente le scelte
     */
    List<StoryChoice> getChoices();

    /**
     * Restituisce il nemico presente nella stanza, se esiste.
     * 
     * @return se presente, il nemico come Enemy
     */
    Enemy getEnemy();

    /**
     * Indica se nella stanza è presente un nemico.
     * 
     * @return true se presente, false altrimenti
     */
    boolean hasEnemy();
    
    /**
     * Restituisce la presenza o l'assenza di aria infetta nella stanza.
     * 
     * @return true se è presente aria infetta, false altrimenti
     */    
    boolean getInfection();    

    /**
     * Restituisce il messaggio (se presente) mostrato all'ingresso della stanza.
     * 
     * @return il messaggio come String
     */        
    String getRoomMessage();
    
    /**
     * Rimuove una scelta dalla stanza.
     * 
     * NOTA: Questo metodo non è utilizzato nella versione attuale, 
     * ma è mantenuto per possibili implementazioni future.
     * 
     * @param choice la scelta da rimuovere dalla stanza
     */
    //void removeChoice(StoryChoice choice);

}
