package main.model.story;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

/**
 * Implementazione dell'interfaccia Room.
 */
public class RoomImpl implements Room {
	
	/**
	 * Identificatore univoco di versione per la serializzazione dell'oggetto.
	 * Garantisce compatibilità tra versioni della classe salvate/caricate da file.
	 * Versione 1 serializzabile della classe.
	 */
	private static final long serialVersionUID = 1L;

	private final int id;
	private final String title;
	private final String description;
	private final List<StoryChoice> choices; // Utilizzo di List per mantenere l'ordine di inserimento definito nella storia (story_01.json)
	private final Enemy enemy;
	private final boolean infection;
	private final String roomMessage; // Messaggio (se presente) mostrato all'ingresso della stanza
	
	public RoomImpl(int id, String title, String description, List<StoryChoice> choices, Enemy enemy, boolean infection, String message) {
		// Utilizzo di Set perché le scelte all'interno della stessa stanza devono essere diverse.
		// HashSet elimina automaticamente gli elementi (StoryChoiceImpl) duplicati,
		// considerati uguali secondo i metodi equals() e hashCode().
        Set<StoryChoice> noStoryChoiceDuplicates = new HashSet<>(choices);
        if (noStoryChoiceDuplicates.size() != choices.size()) {
            throw new IllegalArgumentException("La lista delle scelte contiene duplicati.");
        }
		
		this.id = id;
		this.title = title;
		this.description = description;
		this.choices = new ArrayList<>(choices);
		this.enemy = enemy;
		this.infection = infection;
		this.roomMessage = message;
	}

	@Override
	public int getId() {
		return this.id;
	}
	
	@Override
	public String getTitle() {
		return this.title;
	}	

	@Override
	public String getDescription() {
		return this.description;
	}
	
	@Override
	public void addChoice(StoryChoice choice) {
		this.choices.add(choice);
	}

	@Override
	public List<StoryChoice> getChoices() {
		return new ArrayList<StoryChoice>(this.choices); // Per evitare modifiche esterne alla lista di scelte
	}

	@Override
	public Enemy getEnemy() {
		return this.enemy;
	}

	@Override
	public boolean hasEnemy() {
		return this.enemy != null;
	}
	
	@Override
	public boolean getInfection() {
		return this.infection;
	}
	
	@Override
	public String getRoomMessage() {
		return this.roomMessage;
	}	
	
    /**
     * Due Room sono considerate uguali se hanno lo stesso Id.
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        
        if (!(obj instanceof Room))
            return false;
        
        Room otherRoom = (Room) obj;
        return Objects.equals(this.id, otherRoom.getId());
    }

    /**
     * Calcola un valore hash per l'oggetto Room, in coerenza con equals(Object obj).
     */     
    @Override
    public int hashCode() {
        return Objects.hash(this.id);
    }

    @Override
    public String toString() {
        return "Room[" + this.id + "]";
    }
	
	// Non utilizzato nella versione attuale
	/*
	@Override
	public void removeChoice(StoryChoice choice) {
		this.choices.remove(choice);
	}
	*/

}
