package main.model.story;

import java.io.Serializable;

import main.model.game.Game;

/**
 * Interfaccia che rappresenta una scelta disponibile in una stanza.
 * Ogni scelta ha un testo descrittivo e può portare a una nuova Room (stanza).
 */
public interface StoryChoice extends Serializable {
	
    /**
     * Restituisce l'Id dell'oggetto.
     * 
     * @return l'Id dell'oggetto come int
     */
	int getId();
	
    /**
     * Restituisce la descrizione della scelta, visibile al giocatore.
     * 
     * @return il testo della scelta come String
     */
    String getDescription();

    /**
     * Restituisce la scena a cui conduce questa scelta.
     * 
     * @return Room la scena di destinazione
     */
    Room getTargetRoom();
    
    /**
     * Indica se la scelta è attualmente disponibile (in base all’inventario o altri vincoli).
     * 
     * @return true se la scelta è possibile, false altrimenti
     */
    boolean isAvailable();
    
    /**
     * Applica gli effetti della scelta alla partita e imposta la stanza di destionazione.
     * 
     * @param game la partita su cui applicare la logica della scelta
     */
    void apply(Game game);    

}
