package main.model.story;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import main.model.game.Game;
import main.model.game.SerializableConsumer;
import main.model.game.SerializableSupplier;

public class StoryChoiceImpl implements StoryChoice {

	/**
	 * Identificatore univoco di versione per la serializzazione dell'oggetto.
	 * Garantisce compatibilità tra versioni della classe salvate/caricate da file.
	 * Versione 1 serializzabile della classe.
	 */
	private static final long serialVersionUID = 1L;

	private final int id;
	private final String description;
	private final Room targetRoom;
	private final SerializableSupplier<Boolean> availabilityCondition; // Condizione di disponibilità della scelta
	private final List<SerializableConsumer<Game>> effects; // Lista degli effetti da applicare al gioco
	
	public StoryChoiceImpl(int id, String description, Room targetRoom, SerializableSupplier<Boolean> availabilityCondition, List<SerializableConsumer<Game>> effects) {
		this.id = id;
		this.description = description;
		this.targetRoom = targetRoom;
		this.availabilityCondition = availabilityCondition;
		this.effects = effects != null ? effects : new ArrayList<>();
	}

	@Override
	public int getId() {
		return this.id;
	}
	
	@Override
	public String getDescription() {
		return this.description;
	}

	@Override
	public Room getTargetRoom() {
		return this.targetRoom;
	}

	@Override
	public boolean isAvailable() {
		return this.availabilityCondition.get();
	}

	@Override
	public void apply(Game game) {
	    Room previousRoom = game.getCurrentRoom(); // Salva la stanza corrente

	    // Applica tutti gli effetti
	    for (SerializableConsumer<Game> effect : this.effects) {
	        effect.accept(game);
	    }

	    // Se dopo gli effetti la stanza è rimasta la stessa, applica il targetRoom
	    if (this.targetRoom != null && game.getCurrentRoom() == previousRoom)
	        game.setCurrentRoom(this.targetRoom);
	}

    /**
     * Due StoryChoice sono considerate uguali se hanno lo stesso Id.
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        
        if (!(obj instanceof StoryChoice))
            return false;
        
        StoryChoice otherStoryChoice = (StoryChoice) obj;
        return Objects.equals(this.id, otherStoryChoice.getId());
    }

    /**
     * Calcola un valore hash per l'oggetto StoryChoice, in coerenza con equals(Object obj).
     */      
    @Override
    public int hashCode() {
        return Objects.hash(this.id);
    }

    @Override
    public String toString() {
        return "StoryChoice[" + this.id + "]";
    }
    
}
