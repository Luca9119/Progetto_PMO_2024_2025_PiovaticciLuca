package main.util;

/**
 * Una generica e non modificabile Pair<X,Y>, con getters, hashCode, equals, e toString.
 *
 * NOTA: Questa classe non è utilizzato nella versione attuale,
 * ma è mantenuta per possibili implementazioni future.
 *
 * @param <X> il tipo del primo elemento
 * @param <Y> il tipo del secondo elemento
 */
public final class Pair<X, Y> {
	
    private X x;
    private Y y;

    /**
     * Metodo costruttore.
     * 
     * @param x il primo valore
     * @param y il secondo valore
     */
    public Pair(final X x, final Y y) {
        super();
        this.x = x;
        this.y = y;
    }

    /**
     * Restituisce il primo valore.
     * 
     * @return primo valore
     */
    public X getX() {
        return x;
    }

    /**
     * Restituisce il secondo valore.
     * 
     * @return secondo valore
     */
    public Y getY() {
        return y;
    }
    
    /**
     * Cambia il primo valore
     * 
     * @param il valore da impostare
     */
    public void setX(X x) {
        this.x = x;
    }

    /**
     * Cambia il secondo valore
     * 
     * @param il valore da impostare
     */
    public void setY(Y y) {
        this.y = y;
    }

    @Override
    public String toString() {
        return "[" + x + ", " + y + "]";
    }

    @Override
    public int hashCode() {
        return x.hashCode() ^ y.hashCode();
    }

    @Override
    public boolean equals(final Object obj) {
        return obj instanceof Pair ? x.equals(((Pair<?, ?>) obj).x) && y.equals(((Pair<?, ?>) obj).y) : false;
    }

}
