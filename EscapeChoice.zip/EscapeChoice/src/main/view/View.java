package main.view;

/**
 * Interfaccia View dell'MVC che rappresenta la GUI.
 * Espone l'unico metodo essenziale per avviare la GUI nel main.
 */
public interface View {
	
    /**
     * Avvia la GUI (main), mostrando la schermata iniziale.
     */
    void start();

}
