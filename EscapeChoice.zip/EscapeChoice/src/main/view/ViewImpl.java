package main.view;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.util.List;

import main.controller.Controller;
import main.model.ModelListener;
import main.model.game.Difficulty;

/**
 * Implementazione dell'interfaccia View.
 * Gestisce la GUI del gioco Escape Choice utilizzando Java Swing.
 */
public class ViewImpl implements View, ModelListener {
	
	// Stringhe per i nomi dei pannelli
    private static final String PANEL_START = "start";
    private static final String PANEL_GAME = "game";
    private static final String PANEL_VICTORY = "victory";
    private static final String PANEL_GAME_OVER = "gameover";

    private Controller controller; // Riferimento MVC al Controller
    private JFrame frame; // Finestra principale
    private CardLayout cardLayout; // Gestore layout per cambiare schermate
    private JPanel mainPanel; // Pannello container principale
    
    private String playerName; // Nome del giocatore, inserito dall'utente
    private Difficulty difficulty; // Difficoltà della partita, selezionata dall'utente

    // Componenti schermata iniziale
    private JTextField nameField;
    private JComboBox<Difficulty> difficultyBox;
    private JButton startButton;
    
    // Componenti per la schermata di gioco
    private JTextArea roomDescription;
    private JPanel choicesPanel;
    private JLabel nameLabel;
    private JLabel difficultyLabel;
    private JLabel livesLabel;
    private JLabel inventoryLabel;
    private JLabel infectionLabel;
	
    /**
     * Costruttore della View: riceve il Controller con cui interagire.
     * 
     * @param controller il controller dell'applicazione
     */       
	public ViewImpl(Controller controller) {
		this.controller = controller;
		this.initGUI(); // Inizializza interfaccia grafica
	}
	
    /**
     * Inizializza la finestra e le schermate (panel).
     */
    private void initGUI() {
        this.frame = new JFrame("Escape Choice"); // Crea finestra
        this.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Chiude app a uscita
        this.frame.setSize(1000, 600); // Dimensione finestra
        this.frame.setLocationRelativeTo(null); // Centra la finestra

        this.cardLayout = new CardLayout(); // Layout a schede
        this.mainPanel = new JPanel(cardLayout); // Pannello con layout a schede

        // Aggiunge i panel principali
        this.mainPanel.add(buildStartPanel(), PANEL_START);
        this.mainPanel.add(buildGamePanel(), PANEL_GAME);
        this.mainPanel.add(buildVictoryPanel(), PANEL_VICTORY);
        this.mainPanel.add(buildGameOverPanel(), PANEL_GAME_OVER);

        this.frame.setContentPane(mainPanel); // Imposta pannello principale
    }
    
    /**
     * Implementa la schermata iniziale con nome e difficoltà.
     */
    private JPanel buildStartPanel() {
        JPanel panel = new JPanel(new GridBagLayout()); // Layout flessibile
        
        // Utilizzo di un oggetto GridBagConstraints con layout GridBagLayout,
        // per posizionare i componenti.
        GridBagConstraints gbc = new GridBagConstraints(); // Vincoli per layout

        JLabel nameLabel = new JLabel("Nome giocatore:");
        this.nameField = new JTextField(15); // Campo input nome

        JLabel difficultyLabel = new JLabel("Difficoltà:");
        this.difficultyBox = new JComboBox<>(Difficulty.values()); // ComboBox con difficoltà

        this.startButton = new JButton("Inizia partita");
        this.startButton.addActionListener(e -> { // Listener bottone
            String playerName = this.nameField.getText().trim();
            Difficulty difficulty = (Difficulty) this.difficultyBox.getSelectedItem();
            if (!playerName.isEmpty() && difficulty != null) {
            	this.playerName = playerName;
            	this.difficulty = difficulty;
            	
            	// Aggiorna i testi per le label nameLabel e difficultyLabel
                this.nameLabel.setText("Giocatore: " + this.playerName);
                this.difficultyLabel.setText("Difficoltà: " + this.difficulty);            	
            	
                this.controller.startGame(this.playerName, this.difficulty); // Avvia gioco
            } else {
                JOptionPane.showMessageDialog(frame, "Inserisci nome e difficoltà");
            }
        });
        
        // gridx rappresenta la colonna
        // gridy rappresenta la riga
        // gridwidth rappresenta quante colonne sono occupate
        
        gbc.insets = new Insets(10, 10, 10, 10); // Margini interni
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(nameLabel, gbc); // Aggiungi etichetta nome
        gbc.gridx = 1;
        panel.add(this.nameField, gbc); // Aggiungi campo nome

        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(difficultyLabel, gbc); // Aggiungi etichetta difficoltà
        gbc.gridx = 1;
        panel.add(this.difficultyBox, gbc); // Aggiungi ComboBox difficoltà

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        panel.add(this.startButton, gbc); // Aggiunge bottone
        
        JPanel loadPanel = new JPanel(new GridLayout(1, 2)); // Crea pannello per bottone di caricamento

        // Bottone caricamento partita
        JButton loadButton = new JButton("Carica partita"); // Crea bottone
        loadButton.addActionListener(e -> loadGame());

        // Aggiunge bottone caricamento
        loadPanel.add(loadButton); 
        
        // Posizione del bottone caricamento
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        panel.add(loadPanel, gbc);
        
        return panel;
    }
    
    /**
     * Implementa la schermata principale del gioco.
     */
    private JPanel buildGamePanel() {
        JPanel panel = new JPanel(new BorderLayout()); // Layout con componenti posizionati in aree fisse

        // Area di testo della scena
        this.roomDescription = new JTextArea();
        this.roomDescription.setEditable(false); // Non modificabile
        this.roomDescription.setLineWrap(true); // A capo automatico
        this.roomDescription.setWrapStyleWord(true); // Interruzione su parole
        this.roomDescription.setMargin(new Insets(10, 10, 10, 10));  // Margini interni
        JScrollPane scroll = new JScrollPane(this.roomDescription); // Scroll automatico

        // Pannello centrale che contiene area di testo e scelte
        JPanel centerPanel = new JPanel(new BorderLayout(0, 10)); // 0px orizzontale, 10px verticale di spazio

        // Aggiunge area di testo nella parte centrale
        centerPanel.add(scroll, BorderLayout.CENTER);

        // Pannello delle scelte
        this.choicesPanel = new JPanel();
        this.choicesPanel.setLayout(new GridLayout(0, 1, 5, 5)); // Una colonna, righe dinamiche
        centerPanel.add(this.choicesPanel, BorderLayout.SOUTH); // Aggiunge pannello delle scelte sotto

        // Aggiunge pannello centrale al pannello principale
        panel.add(centerPanel, BorderLayout.CENTER);

        // Pannello per la barra di stato (vite, inventario, infezione)
        JPanel statusPanel = new JPanel(new GridLayout(1, 5));
        this.nameLabel = new JLabel("Giocatore: " + this.playerName);
        this.difficultyLabel = new JLabel("Difficoltà: " + this.difficulty);
        this.livesLabel = new JLabel("Vite: ");
        this.inventoryLabel = new JLabel("Inventario: ");
        this.infectionLabel = new JLabel("Infezione: ");
        statusPanel.add(this.nameLabel); // Aggiunge label del nome al pannello di stato
        statusPanel.add(this.difficultyLabel); // Aggiunge label della difficoltà al pannello di stato
        statusPanel.add(this.livesLabel); // Aggiunge label delle vite al pannello di stato
        statusPanel.add(this.inventoryLabel); // Aggiunge label dell'inventario al pannello di stato
        statusPanel.add(this.infectionLabel); // Aggiunge label dell'infezione al pannello di stato
        panel.add(statusPanel, BorderLayout.NORTH); // Aggiunge pannello di stato in alto

        // Bottone Popup menu
        JPanel menuPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT)); // Allinea a destra
        JButton menuButton = new JButton("Menu");

        // Crea Popup menu
        JPopupMenu popupMenu = new JPopupMenu();

        // Voce menu Salva partita
        JMenuItem saveItem = new JMenuItem("Salva partita");
        saveItem.addActionListener(e -> this.saveGame());
        popupMenu.add(saveItem);

        // Voce menu Carica partita
        JMenuItem loadItem = new JMenuItem("Carica partita");
        loadItem.addActionListener(e -> this.loadGame());
        popupMenu.add(loadItem);

        // Mostra menu al click del bottone
        menuButton.addActionListener(e -> popupMenu.show(menuButton, 0, menuButton.getHeight()));
        menuPanel.add(menuButton); // Aggiungi bottone al pannello menu
        panel.add(menuPanel, BorderLayout.EAST); // Aggiunge il menuPanel a destra    
        
        return panel;
    }   
    
    /**
     * Implementa la schermata visualizzata in caso di vittoria.
     */
    private JPanel buildVictoryPanel() {
        JPanel panel = new JPanel();
        panel.add(new JLabel(ViewTexts.VICTORY)); // Messaggio vittoria
        
        return panel;
    }
    
    /**
     * Implementa la schermata visualizzata in caso di game over.
     */
    private JPanel buildGameOverPanel() {
        JPanel panel = new JPanel();
        panel.add(new JLabel(ViewTexts.GAMEOVER)); // Messaggio sconfitta
        
        return panel;
    }

	@Override
	public void start() {
		this.frame.setVisible(true); // Mostra finestra
        this.cardLayout.show(this.mainPanel, PANEL_START); // Mostra schermata iniziale
	}

    /**
     * Mostra un messaggio di testo all’utente.
     * 
     * @param message il messaggio da visualizzare
     */	
	private void showMessage(String message) {
		// Mostra messaggio. PLAIN_MESSAGE: nessuna icona mostrata
		JOptionPane.showMessageDialog(this.frame, message, "Messaggio", JOptionPane.PLAIN_MESSAGE);
	}
	
    /**
     * Mostra un messaggio in una finestra non modale.
     * Utile per non bloccare le interazioni con l'applicazione finché non viene chiusa
     * 
     * @param message il messaggio da mostrare
     */
	private void showModelessMessage(String message) {
	    JDialog dialog = new JDialog(this.frame, "Messaggio", false); // false = finestra (dialog) non modale
	    dialog.setLayout(new BorderLayout()); // Imposta il layout del contenitore del finestra su BorderLayout
	    dialog.add(new JLabel(message, SwingConstants.CENTER), BorderLayout.CENTER); // Aggiunge al centro del finestra un JLabel con il messaggio
	    dialog.setSize(500, 100); // Dimensioni
	    dialog.setLocationRelativeTo(this.frame); // Centra la finestra rispetto alla finestra principale
	    new javax.swing.Timer(4000, e -> dialog.dispose()).start(); // Timer per chiudere il messaggio dopo 4 secondi
	    dialog.setVisible(true); // Rende visibile la finestra
	}	
	
    /**
     * Salva lo stato della partita su un nuovo file in formato binario (.dat).
     * Mostra un messaggio di conferma o errore.
     */ 
	private void saveGame() {
        try {
            // Crea cartella saves se non esiste
            File saveDir = new File("saves");
            saveDir.mkdirs();

            // Nome file con timestamp
            String timestamp = new java.text.SimpleDateFormat("yyyyMMdd_HHmmss").format(new java.util.Date());
            String binFile = "saves/Salvataggio_" + timestamp + ".dat";
            this.controller.saveGame(binFile); // Salva
            this.showMessage("Partita salvata:\n" + binFile + "\n"); // Messaggio
        } catch (Exception ex) {
            this.showMessage("Errore nel salvataggio: " + ex.getMessage());
        }
	}
	
    /**
     * Carica lo stato della partita dal file selezionato.
     * Mostra un messaggio di conferma o errore.
     */
	private void loadGame() {
	    try {
	    	// Apertura selettore file nella cartella "saves"
	        JFileChooser fileChooser = new JFileChooser("saves");
	        fileChooser.setFileFilter(new javax.swing
	        		.filechooser
	        		.FileNameExtensionFilter("Salvataggi Escape Choice (.dat)", "dat"));
	        int result = fileChooser.showOpenDialog(this.frame);

	        if (result == JFileChooser.APPROVE_OPTION) {
	            File selectedFile = fileChooser.getSelectedFile();
	            if (selectedFile.getName().endsWith(".dat")) { // Permette solo file binari .dat
	                this.controller.loadGame(selectedFile.getAbsolutePath()); // Chiede al Controller di caricare la partita
	                this.showMessage("Partita caricata: " + selectedFile.getName()); // Mostra conferma: la GUI vera sarà aggiornata dal Model 
	            } else {// Se estensione non supportata
	                this.showMessage("Formato file non supportato.");
	            }
	        }
	    } catch (Exception ex) {
	        this.showMessage("Errore nel caricamento: " + ex.getMessage());
	    }
	}

	@Override
	public void onRoomUpdated(String playerName, Difficulty difficulty, String description, List<String> choices, int lives, List<String> inventory, String infectionLabel) {
		// Aggiornamenti della label
		this.nameLabel.setText("Giocatore: " + playerName);
	    this.difficultyLabel.setText("Difficoltà: " + difficulty);
	    this.livesLabel.setText("Vite: " + lives);
	    this.inventoryLabel.setText("Inventario: " + (inventory.isEmpty() ? "Vuoto" : inventory.toString())); 
	    this.infectionLabel.setText("Infezione: " + infectionLabel); 
	    
	    // Aggiorna la descrizione della stanza con il testo ricevuto dal Model
	    this.roomDescription.setText(description); 

	    // Rimuove tutti i bottoni di scelta precedenti per ricreare la lista in base allo stato attuale
	    this.choicesPanel.removeAll(); 
	    
	    // Ciclo scelte fornite dal Model
	    for (int i = 0; i < choices.size(); i++) { 
	        final String choiceText = choices.get(i); // Recupera il testo
	        final int index = i; // Salva l’indice in una variabile final per l’uso nel listener (lambda)
	        JButton button = new JButton(choiceText); // Crea un bottone
	        
	        // Al click notifica il Controller passando l’indice della scelta
	        button.addActionListener(e -> this.controller.handleChoiceIndex(index)); 
	        
	        this.choicesPanel.add(button); // Aggiunge il bottone al pannello delle scelte
	    }

	    this.choicesPanel.revalidate(); // Refresh pannello scelte dopo modifiche
	    this.choicesPanel.repaint(); // Rapaint
	    this.cardLayout.show(this.mainPanel, PANEL_GAME); // Mostra il pannello
	}
	
	@Override
	public void onStatusTick(int lives, String infectionLabel) {
	    this.livesLabel.setText("Vite: " + lives); // Aggiorna label vite
	    this.infectionLabel.setText("Infezione: " + infectionLabel); // Aggiorna label infezione
	}	

	@Override
	public void onVictory() {
	    this.cardLayout.show(this.mainPanel, PANEL_VICTORY); // Mostra pannello vittoria
	}

	@Override
	public void onGameOver() {
	    this.cardLayout.show(this.mainPanel, PANEL_GAME_OVER); // Mostra pannello game over 
	}

	@Override
	public void onMessage(String message) {
	    // Non modale se è il messaggio di perdita vita per infezione
	    if (message != null && message.equals(ViewTexts.LIFE_LOST_INFECTION_MSG)) {
	        this.showModelessMessage(message);
	    } else { // Modali tutti gli altri messaggi
	        this.showMessage(message);
	    }
	}
	
	@Override
	public void onModelessMessage(String message) {
	    this.showModelessMessage(message); // Mostra popup non bloccante che si chiude da solo
	}

}
