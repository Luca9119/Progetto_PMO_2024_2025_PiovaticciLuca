package main.view;

/**
 * Classe di utility che contiene alcuni testi fissi usati dall'interfaccia grafica (GUI),
 * non riguardano la logica del gioco.
 * 
 * Non ha istanze: contiene solo costanti pubbliche.
 * 
 * NOTA: Saranno aggiunti altri testi,
 * in possibili implementazioni future.
 * 
 * Centralizzare le stringhe costanti della View.
 */
public final class ViewTexts {
	
	public static final String VICTORY = "🎉 VITTORIA!";
	public static final String GAMEOVER = "☠️ GAME OVER";
	public static final String LIFE_LOST_INFECTION_MSG = "⚠️ ATTENZIONE: Hai perso 1 vita a causa dell'infezione!";
	public static final String GAMEOVER_INFECTION_MSG = "⚠️ TROPPO TARDI! L'infezione ti ha consumato...";
	
    /**
     * Costruttore privato per impedire l'istanziazione della classe.
     */
	private ViewTexts() {};	

}
