package test;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import main.model.game.*;
import main.model.player.*;
import main.model.story.*;

/**
 * Classe di test JUnit per GameImpl.
 * Verifica:
 * _ La logica del timer infezione (l'infezione riduce progressivamente le vite, 
 * e quando le vite terminano il Player e il Game cambiano stato).
 * _ L'attacco dei nemici al Player.
 */
public class GameTest {

    /**
     * Metodo di setup.
     * Inizializza il contesto per il test:
     * crea una nuova partita con un Player e una Room iniziale.
     *
     * @param initialLives numero di vite iniziali da assegnare al Player come int
     * 
     * @return GameImpl con il player pronto per i test
     */
    private GameImpl initGame(int initialLives) {
        Inventory inventory = new InventoryImpl();
        Infection infection = new InfectionImpl(1000); // Costruttore configurabile: 1 vita persa ogni secondo
        Player player = new PlayerImpl(1, "Luca", initialLives, inventory, infection);
        GameImpl game = new GameImpl(Difficulty.MEDIUM);
        game.addPlayer(player); // Aggiunge il player alla partita
        
        // Imposta una stanza fittizia (evita NullPointerException)
        Room startRoom = new RoomImpl(1, "Start", "Stanza iniziale di test", new ArrayList<>(), null, false, null);
        
        game.setCurrentRoom(startRoom); // Imposta una stanza nel gioco
        game.start(); // Avvia la partita: stato partita = ON, avvio del timer infezione
        return game;
    }

    /**
     * Test per verificare che l'infezione riduca progressivamente le vite del player.
     */
    @Test
    public void testInfectionReducesLives() throws InterruptedException {
        GameImpl game = initGame(3); // Player con 3 vite
        Player player = game.getPlayers().get(0); // Recupera il Player (unico in questa versione)
        assertFalse(player.isInfected()); // Verifica che il Player non sia infetto prima di attivare l'infezione (false)
        player.infect(); // Infetta il player
        assertTrue(player.isInfected()); // Verifica che il Player sia infetto dopo l'attivazione dell'infezione (true)
        int initialLives = player.getLives(); // Salva vite iniziali
        
        // Attende 1.5 secondi per avere il tempo necessario di perdere 1 vita (1 secondo)
        // Questo garantisce che la TimerTask abbia avuto il tempo di aggiornare l'infezione.
        Thread.sleep(1500);

        // Verifica che il numero di vite del player sia inferiore a quello iniziale (true)
        assertTrue(player.getLives() < initialLives); 
    }

    /**
     * Test per verificare che l'infezione porti a game over e termini la partita, quando le vite finiscono.
     */
    @Test
    public void testInfectionChangeToGameOver() throws InterruptedException {
    	GameImpl game = initGame(1); // Player con 1 vita
        Player player = game.getPlayers().get(0); // Recupera il Player (unico in questa versione)
        assertFalse(player.isInfected()); // Verifica che il Player non sia infetto prima di attivare l'infezione (false)
        player.infect(); // Attiva infezione
        assertTrue(player.isInfected()); // Verifica che il Player sia infetto dopo l'attivazione dell'infezione (true)
        
        // Attende 1.5 secondi per avere il tempo necessario di perdere 1 vita (1 secondo)
        // Questo garantisce che la TimerTask abbia avuto il tempo di aggiornare l'infezione.
        Thread.sleep(1500);
        
        assertEquals(PlayerState.GAME_OVER, player.getPlayerState()); // Verifica che lo stato del player sia passato a GAME_OVER 
        assertEquals(GameState.OFF, game.getGameState()); // Verifica che la partita sia terminata
    }
    
    /**
     * Test per verificare che attack() di Enemy con strength=1 e Player senza oggetto difensivo
     */
    @Test
    public void testEnemyAttackPlayerNoItem() {
        GameImpl game = initGame(3); // Player con 3 vite
        Player player = game.getPlayers().get(0); // Recupera il Player (unico in questa versione)
        int initialLives = player.getLives(); // Salva vite iniziali
        Enemy enemy = new EnemyImpl("Nemico", 1, null); // Crea un nemico con forza di attacco 1
        assertEquals(1, enemy.getStrength()); // Verifica la forza del nemico
        enemy.attack(player); // Nemico attacca il Player
        assertEquals(initialLives - 1, player.getLives()); // Verifica il decremento di vite dopo l'attacco
    }
    
    /**
     * Test per verificare che attack() di Enemy con strength=1 e Player con oggetto difensivo
     * NON riduca le vite del Player.
     */
    @Test
    public void testEnemyAttackPlayerItem() {
        GameImpl game = initGame(3); // Player con 3 vite
        Player player = game.getPlayers().get(0); // Recupera il Player (unico in questa versione)
        int initialLives = player.getLives(); // Salva vite iniziali
        Item item = new ItemImpl("arma"); // Crea un oggetto
        player.addItem(item); // Aggiunge oggetto al Player
        Enemy enemy = new EnemyImpl("Nemico", 1, item); // Crea un nemico con forza di attacco 1
        assertEquals(1, enemy.getStrength()); // Verifica la forza del nemico
        boolean survived = enemy.attack(player); // Nemico attacca il Player
        assertTrue(survived); // Verifica che il player sia sopravvissuto (true)
        assertEquals(initialLives, player.getLives()); // Verifica che il player non abbia perso vite (true)
    }

    /**
     * Test per verificare che attack() di Enemy con strength>1 e Player senza oggetto difensivo,
     * porti direttamente a GAME_OVER.
     */
    @Test
    public void testMultipleEnemyAttackPlayerNoItem() {
        GameImpl game = initGame(2); // Player con 2 vite
        Player player = game.getPlayers().get(0); // Recupera il Player (unico in questa versione)
        Enemy enemy = new EnemyImpl("Nemico", 2, null); // Crea un nemico con forza di attacco 2
        assertEquals(2, enemy.getStrength()); // Verifica la forza del nemico
        boolean survived = enemy.attack(player); // Nemico attacca il Player
        assertFalse(survived); // Verifica che il player non sia sopravvissuto (false)
        assertEquals(PlayerState.GAME_OVER, player.getPlayerState()); // Verifica che lo stato del player sia GAME_OVER (true)
    }    
    
}
