package test;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import main.model.player.*;

/**
 * Classe di test JUnit per PlayerImpl.
 * Funzionalità del giocatore testate: vite, inventario e infezione.
 */
public class PlayerTest {
	
    private Player player;
    private Inventory inventory;
    private Infection infection;

    /**
     * Metodo di setup.
     * Inizializza il contesto per il test.
     */       
    public void init() {
        inventory = new InventoryImpl();
        infection = new InfectionImpl();
        player = new PlayerImpl(1, "Luca", 3, inventory, infection);
    }

    /**
     * Test iniziale del Player.
     */
    @Test
    public void testPlayerInitialization() {
        init(); // Inizializza
        assertEquals(1, player.getId()); // Verifica id
        assertEquals("Luca", player.getName()); // Verifica nome
        assertEquals(3, player.getLives()); // Verifica vite
        assertEquals(PlayerState.IS_PLAYING, player.getPlayerState()); // Verifica stato iniziale IS_PLAYING
        assertFalse(player.isInfected()); // Verifica infezione iniziale (false)
        assertTrue(player.getInventory().getItems().isEmpty()); // Verifica inventario iniziale (true)
    }

    /**
     * Test aggiunta di 1 vita.
     */
    @Test
    public void testAddLife() {
        init(); // Inizializza
        player.addLife();
        assertEquals(4, player.getLives()); // Verifica incremento vite
    }
    
    /**
     * Test limite massimo delle vite (max 6).
     */
    @Test
    public void testLifeLimit() {
        init(); // Inizializza
        for (int i = 0; i < 10; i++) { // Aggiunge vite
            player.addLife();
        }
        assertEquals(6, player.getLives()); // Verifica che non superi 6
    }

    /**
     * Test perdita di 1 vita.
     */
    @Test
    public void testLoseLife() {
    	init(); // Inizializza
        player.loseLife();
        assertEquals(2, player.getLives()); // Verifica decremento vite
    }

    /**
     * Test perdita di tutte le vite.
     */
    @Test
    public void testLoseAllLives() {
    	init(); // Inizializza
        player.loseLife();
        player.loseLife();
        player.loseLife();
        assertEquals(0, player.getLives()); // Verifica che le vite siano arrivate a 0

        // Verifica che lo stato rimanga IS_PLAYING (getLives() non cambia stato in GAME_OVER)
        assertEquals(PlayerState.IS_PLAYING, player.getPlayerState());
    }

    /**
     * Test aggiunta di un oggetto all'inventario.
     */
    @Test
    public void testInventoryAddItem() {
    	init(); // Inizializza
        Item item = new ItemImpl("oggetto");
        assertFalse(player.hasItem(item)); // Verifica che il Player non possieda item prima di aggiungerlo (false)
        player.addItem(item);
        assertTrue(player.hasItem(item)); // Verifica che il Player possieda item dopo averlo aggiunto (true)
        assertEquals(1, player.getInventory().getItems().size()); // Verifica che l’inventario contenga un elemento
    }

    /**
     * Test attivazione infezione.
     */
    @Test
    public void testInfectionActivation() {
    	init(); // Inizializza
        assertFalse(player.isInfected()); // Verifica che inizialmente il Player non sia infetto
        player.infect();
        assertTrue(player.isInfected()); // Verifica che il Player sia infetto
        assertTrue(player.getInfection().getRemainingTime() > 0); // Verifica che il timer dell’infezione sia partito (tempo > 0)
    }

    /**
     * Test effetto del timer infezione sulle vite.
     */
    @Test
    public void testUpdateInfectionTimer() {
    	init(); // Inizializza
        int livesBefore = player.getLives(); // Salva il numero di vite prima dell'aggiornamento del timer
        player.infect();
        player.updateInfectionTimer(); // Questo metodo decrementa la vita se il timer segnala di farlo
        assertTrue(player.getLives() <= livesBefore); // Verifica che le vite siano diminuite o uguali a quelle iniziali
    }   

}
