package test;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import main.model.*;
import main.model.game.*;
import main.model.player.*;
import main.model.story.*;

import java.io.File;

/**
 * Classe di test JUnit per il salvataggio e caricamento binario della partita.
 * Verifica che lo stato del gioco sia identico dopo un salvataggio/caricamento,
 * e che il timer infezione venga riavviato correttamente.
 */
public class SaveLoadGameTest {
	
    /**
     * Metodo di setup.
     * Inizializza il contesto per il test:
     * crea il model e avvia la partita.
     * 
     * @return Model dell'applicazione
     */ 	
    private Model initModel() {
        Model model = new ModelImpl(); // Istanzia il Model
        model.startNewGame("Luca", Difficulty.MEDIUM); // Avvia nuova partita
        return model;
    }

    /**
     * Test di salvataggio e caricamento di base della partita.
     * Verifica che dopo un load il gioco non sia nullo.
     */
    @Test
    public void testSaveLoadNotNull() {
        Model model = initModel(); // Crea partita
        String path = "test_save_load_game.dat"; // File di test
        model.saveGame(path); // Salva partita
        File file = new File(path);
        assertTrue(file.exists()); // Verifica che il file esista (true)
        Model loadModel = new ModelImpl(); // Nuovo model per il caricamento
        loadModel.loadGame(path); // Carica partita
        assertNotNull(loadModel.getPlayers()); // Verifica che i giocatori siano stati caricati
        assertFalse(loadModel.getPlayers().isEmpty()); // Verifica che ci sia almeno un player
        file.delete(); // Cancella file di test
    }

    /**
     * Test per la persistenza dello stato del player (vite e inventario) dopo un salvataggio/caricamento.
     */
    @Test
    public void testSaveLoadPlayerState() {
        Model model = initModel(); // Nuova partita
        Player player = model.getPlayers().get(0); // Recupera il player (unico in questa versione)
        String path = "test_save_load_playerstate.dat"; // File di test
        
        // Modifica lo stato del player prima del salvataggio
        player.loseLife(); // Perde 1 vita
        Item item = new ItemImpl("oggetto");
        player.addItem(item); // Aggiunge item all'inventario del player
        model.saveGame(path); // Salva partita
        File file = new File(path);
        assertTrue(file.exists()); // Verifica che il file esista (true)
        Model loadModel = new ModelImpl(); // Nuovo model per il caricamento
        loadModel.loadGame(path); // Carica partita
        Player loadedPlayer = loadModel.getPlayers().get(0); // Player caricato
        assertEquals(player.getLives(), loadedPlayer.getLives()); // Verifica lo stesso numero di vite
        assertTrue(loadedPlayer.hasItem(item)); // Verifica che item sia presente nell'inventario (true)
        file.delete(); // Cancella file di test
    }

    /**
     * Test per la persistenza della stanza corrente dopo un salvataggio/caricamento.
     */
    @Test
    public void testSaveLoadRoom() {
        Model model = initModel(); // Nuova partita
        Room currentRoom = model.getCurrentRoom(); // Recupera stanza corrente
        String path = "test_save_load_roomstate.dat"; // File di test
        model.saveGame(path); // Salva partita
        File file = new File(path);
        assertTrue(file.exists()); // Verifica che il file esista (true)
        Model loadModel = new ModelImpl(); // Nuovo model per il caricamento
        loadModel.loadGame(path); // Carica partita
        Room loadedRoom = loadModel.getCurrentRoom(); // Stanza caricata
        assertEquals(currentRoom.getId(), loadedRoom.getId()); // Verifica che l'id sia lo stesso
        file.delete(); // Cancella file di test
    }

    /**
     * Test per il riavvio del timer infezione dopo un caricamento.
     */
    @Test
    public void testInfectionTimerAfterLoad() throws InterruptedException {
        Model model = initModel(); // Nuova partita
        Player player = model.getPlayers().get(0); // Recupera il player (unico in questa versione)
        player.infect(); // Attiva infezione
        String path = "test_save_load_infection.dat"; // File di test
        model.saveGame(path); // Salva Partita
        File file = new File(path);
        assertTrue(file.exists()); // Verifica che il file esista (true)
        Model loadModel = new ModelImpl(); // Nuovo model per il caricamento
        loadModel.loadGame(path); // Carica partita
        Player loadedPlayer = loadModel.getPlayers().get(0); // Player caricato
        assertTrue(loadedPlayer.isInfected()); // Verifica che dopo il caricamento l'infezione sia ancora attiva (true)  
        
        // Attende 1 secondo per dare tempo al timer di aggiornarsi (INFECTION_CHECK_TIME = 1000 ms).
        // Questo garantisce che la TimerTask abbia avuto il tempo di aggiornare l'infezione.
        // Se meno, rischia che il timer non sia ancora partito: test instabile.
        // Se più, renderebbe il test più lento.
        Thread.sleep(1000); 
        
        // Verifica che il timer sia in esecuzione e che il tempo rimanente sia > 0 (true)
        assertTrue(loadedPlayer.getInfection().getRemainingTime() > 0); 
        file.delete(); // Cancella file di test
    }	

}
