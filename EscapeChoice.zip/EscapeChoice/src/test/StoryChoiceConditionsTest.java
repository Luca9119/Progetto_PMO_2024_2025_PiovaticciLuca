package test;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import main.model.game.*;
import main.model.player.*;
import main.model.story.*;

import java.util.ArrayList;

/**
 * Classe di test JUnit per le condizioni delle scelte (StoryChoice).
 * Condizioni testate: 
 * always (sempre vera),
 * has_item (vera se l’oggetto è presente nell’inventario),
 * not_has_item (vera se l’oggetto non è presente nell’inventario).
 * 
 * NOTA: la condizione not_has_item è testata, 
 * ma non utilizzata in questa versione della narrazione.
 */
public class StoryChoiceConditionsTest {

    private Player player;
    private Inventory inventory;
    private Infection infection;
    private Game game;
    private Room targetRoom;

    /**
     * Metodo di setup.
     * Inizializza il contesto per il test.
     */    
    private void init() {
        inventory = new InventoryImpl(); // Inventario vuoto inizialmente
        infection = new InfectionImpl(); // Infezione non attiva inizialmente
        player = new PlayerImpl(1, "Luca", 3, inventory, infection);
        game = new GameImpl(Difficulty.MEDIUM);
        game.addPlayer(player);
        targetRoom = new RoomImpl(10, "Stanza target", "Stanza usata come destinazione in base alla scelta", new ArrayList<>(), null, false, null);
    }

    /**
     * Test condizione "always".
     * Deve essere sempre vera indipendentemente dallo stato del player.
     */
    @Test
    public void testConditionAlways() {
        init(); // Inizializza
        StoryChoice choice = new StoryChoiceImpl(
            1,
            "Scelta always",
            targetRoom,
            () -> true, // Condizione sempre vera
            new ArrayList<>() // Nessun effetto
        );
        assertTrue(choice.isAvailable()); // Verifica disponibilità scelta (true)
    }

    /**
     * Test condizione "has_item".
     * Vera se il giocatore possiede nell'inventario l'oggetto richiesto.
     */
    @Test
    public void testConditionHasItem() {
        init(); // Inizializza
        Item item = new ItemImpl("oggetto");
        StoryChoice choice = new StoryChoiceImpl(
            2,
            "Scelta has_item",
            targetRoom,
            () -> player.hasItem(item), // Condizione: il player deve possedere item
            new ArrayList<>() // Nessun effetto
        );
        assertFalse(choice.isAvailable()); // Verifica la disponibilità iniziale della scelta (false senza item)
        player.addItem(item); // Aggiunge item all'inventario del player
        assertTrue(choice.isAvailable()); // Verifica la disponibilità della scelta con item presente (true con item)
    }

    /**
     * Test condizione "not_has_item".
     * Vera se il giocatore non possiede nell'inventario l'oggetto richiesto.
     */
    @Test
    public void testConditionNotHasItem() {
        init(); // Inizializza
        Item item = new ItemImpl("oggetto");
        StoryChoice choice = new StoryChoiceImpl(
            3,
            "Scelta not_has_item",
            targetRoom,
            () -> !player.hasItem(item), // Condizione: il player non deve possedere item
            new ArrayList<>() // Nessun effetto
        );
        assertTrue(choice.isAvailable()); // Verifica la disponibilità iniziale della scelta (true senza item)
        player.addItem(item); // Aggiunge item all'inventario del player
        assertFalse(choice.isAvailable()); // Verifica la disponibilità della scelta con item presente (false con item)
    }
    
}
