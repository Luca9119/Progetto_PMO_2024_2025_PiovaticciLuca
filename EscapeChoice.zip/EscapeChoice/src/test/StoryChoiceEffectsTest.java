package test;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import main.model.game.*;
import main.model.player.*;
import main.model.story.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Classe di test JUnit per gli effetti delle scelte (StoryChoice).
 * Effetti testati: if_has_item, lose_life_random, attack_enemy,
 * add_item, lose_life, infect, winner, game_over, show_message.
 * 
 * NOTA: gli effetti add_item, lose_life, infect, winner, game_over e show_message,
 * sono testati ma non utilizzati come effetto diretto di una scelta,
 * in questa versione della narrazione.
 */
public class StoryChoiceEffectsTest {

    private Player player;
    private Inventory inventory;
    private Infection infection;
    private Game game;
    private Room currentRoom; // Stanza corrente
    private Room targetRoom; // Stanza destinazione (dopo apply)

    /**
     * Metodo di setup.
     * Inizializza il contesto per il test.
     */ 
    private void init() {
        inventory = new InventoryImpl(); // Inventario vuoto inizialmente
        infection = new InfectionImpl(); // Infezione non attiva inizialmente
        player = new PlayerImpl(1, "Luca", 3, inventory, infection);
        game = new GameImpl(Difficulty.MEDIUM);
        game.addPlayer(player);
        currentRoom = new RoomImpl(1, "Current", "Stanza corrente", new ArrayList<>(), null, false, null);  // Stanza corrente
        targetRoom = new RoomImpl(2, "Target", "Stanza target", new ArrayList<>(), null, false, null);  // Stanza destinazione
        game.setCurrentRoom(currentRoom); // Imposta la stanza corrente
    }
    
    /**
     * Test effetto if_has_item:
     * successo con oggetto presente,
     * fallimento senza oggetto.
     */
    @Test
    public void testEffectIfHasItem() {
        init(); // Inizializza
        Item item = new ItemImpl("oggetto"); // Oggetto richiesto
        List<SerializableConsumer<Game>> effects = new ArrayList<>(); // Lista effetti
        effects.add(g -> { // Effetto "if_has_item"
            Player p = g.getPlayers().get(0);
            if (p.hasItem(item)) { // Successo: cambio stanza
                g.addPendingMessage("Successo: oggetto presente");
                g.setCurrentRoom(targetRoom);
            } else {
                p.loseLife(); // Fallimento: perdita di 1 vita
                g.addPendingMessage("Fallimento: oggetto non presente");
            }
        });

        StoryChoice choice = new StoryChoiceImpl(
            7,
            "Prova if_has_item",
            targetRoom,
            () -> true, // Sempre selezionabile
            effects
        );
        
        // Caso oggetto presente
        player.addItem(item); // Aggiunge item all'inventario del player
        choice.apply(game); // Applica gli effetti e cambia stanza
        assertEquals(targetRoom, game.getCurrentRoom()); // Verifica cambio stanza
        assertTrue(game.usePendingMessages().contains("Successo: oggetto presente")); // Verifica la presenza del messaggio (true)

        // Caso oggetto non presente
        player.getInventory().getItems().clear(); // Rimuove item dall'inventario
        int initialLives = player.getLives();
        choice.apply(game); // Applica gli effetti e cambia stanza
        assertEquals(initialLives - 1, player.getLives()); // Verifica il decremento di 1 vita
        assertTrue(game.usePendingMessages().contains("Fallimento: oggetto non presente")); // Verifica la presenza del messaggio (true)
    }
    
    /**
     * Test effetto lose_life_random:
     * decrementa di 1 vita,
     * o aggiunta di un messaggio di successo.
     */
    @Test
    public void testEffectLoseLifeRandom() {
        init(); // Inizializza
        List<SerializableConsumer<Game>> effects = new ArrayList<>(); // Lista effetti
        effects.add(g -> { // Effetto "lose_life_random"
            Player p = g.getPlayers().get(0);
            Random rand = new Random();
            int r = rand.nextInt(2);
            if (r == 1) { // Perdita di 1 vita
                p.loseLife();
                g.addPendingMessage("Hai perso 1 vita!");
            } else { // Messaggio di successo
                g.addPendingMessage("Sei salvo!");
            }
        });

        StoryChoice choice = new StoryChoiceImpl(
            8,
            "Prova lose_life_random",
            targetRoom,
            () -> true, // Sempre selezionabile
            effects
        );

        // Esecuzione ripetuta
        boolean lifeLoss = false;
        boolean safe = false;
        for (int i = 0; i < 20; i++) {
            choice.apply(game); // Applica gli effetti e cambia stanza
            List<String> messages = game.usePendingMessages(); // Lista messaggi
            if (messages.contains("Hai perso 1 vita!")) {
            	lifeLoss = true;
            }
            if (messages.contains("Sei salvo!")) {
                safe = true;
            }
        }

        assertTrue(lifeLoss); // Verifica il decremento di 1 vita (true)
        assertTrue(safe); // Verifica la presenza del messaggio di successo (true)
    }

    /**
     * Test effetto attack_enemy:
     * successo con oggetto difensivo,
     * fallimento senza oggetto.
     */
    @Test
    public void testEffectAttackEnemy() {
        init(); // Inizializza
        Item item = new ItemImpl("arma"); // Item da aggiungere
        Enemy enemy = new EnemyImpl("Robot", 3, item); // Crea un nemico con forza di attacco 3 e requisito "arma"
        currentRoom = new RoomImpl(99, "Stanza con nemico", "Contiene un robot", new ArrayList<>(), enemy, false, null); // Stanza con nemico
        game.setCurrentRoom(currentRoom); // Imposta stanza con nemico
        List<SerializableConsumer<Game>> effects = new ArrayList<>(); // Lista effetti
        effects.add(g -> { // Effetto "attack_enemy"
            Room room = g.getCurrentRoom();
            if (room.hasEnemy()) { // Nemico presente
                Enemy e = room.getEnemy();
                Player p = g.getPlayers().get(0);
                boolean survived = e.attack(p);
                if (!survived) { // Fallimento
                    g.addPendingMessage("❌ Senza arma non puoi affrontare i tre robot: sei sopraffatto e SCONFITTO...");
                    g.setGameState(GameState.OFF);
                } else { // Successo
                    g.addPendingMessage("⚔️ Con la tua arma sei riuscito a liberarti dei tre robot, ma sei rimasto ferito: perdi 1 vita.");
                }
            }
        });

        StoryChoice choice = new StoryChoiceImpl(
            10,
            "Prova attack_enemy",
            targetRoom,
            () -> true, // Sempre selezionabile
            effects
        );

        // Caso con arma (successo)
        player.addItem(item); // Aggiunge item all'inventario del player
        choice.apply(game); // Applica gli effetti e cambia stanza
        List<String> successMessages = game.usePendingMessages();
        assertTrue(successMessages.get(0).startsWith("⚔️ Con la tua arma")); // Verifica la presenza del messaggio (true)
        assertEquals(PlayerState.IS_PLAYING, player.getPlayerState()); // Verifica che il player sia vivo

        // Caso senza arma (fallimento)
        player.getInventory().getItems().clear(); // Rimuove item dall'inventario
        game.setCurrentRoom(currentRoom); // Reimposta la stanza con nemico
        choice.apply(game); // Applica gli effetti e cambia stanza
        List<String> failMessages = game.usePendingMessages();
        assertTrue(failMessages.get(0).startsWith("❌ Senza arma")); // Verifica la presenza del messaggio (true)
        assertTrue(player.getLives() < 3 || player.getPlayerState() == PlayerState.GAME_OVER); // Verifica il decremento di vite o game over
    }

    /**
     * Test effetto add_item: aggiunge un oggetto all'inventario.
     */
    @Test
    public void testEffectAddItem() {
        init(); // Inizializza
        Item item = new ItemImpl("oggetto"); // Item da aggiungere
        List<SerializableConsumer<Game>> effects = new ArrayList<>(); // Lista effetti
        effects.add(game -> game.getPlayers().get(0).addItem(item)); // Effetto add_item: aggiunge item all'inventario del player

        // Scelta con l'effetto add_item
        StoryChoice choice = new StoryChoiceImpl(
                10,
                "Prendi oggetto",
                targetRoom,
                () -> true, // Sempre selezionabile
                effects
        );

        assertFalse(player.hasItem(item)); // Verifica la presenza di item prima di apply (false)
        choice.apply(game); // Applica gli effetti e cambia stanza
        assertTrue(player.hasItem(item)); // Verifica la presenza di item dopo apply (true)
        assertEquals(targetRoom, game.getCurrentRoom()); // Verifica cambio stanza
    }

    /**
     * Test effetto lose_life: decrementa di 1 vita.
     */
    @Test
    public void testEffectLoseLife() {
        init(); // Inizializza
        int currentLives = player.getLives(); // Vite correnti
        List<SerializableConsumer<Game>> effects = new ArrayList<>(); // Lista effetti
        effects.add(g -> g.getPlayers().get(0).loseLife());  // Effetto lose_life: perdita di 1 vita

        // Scelta con l'effetto lose_life
        StoryChoice choice = new StoryChoiceImpl(
                11,
                "Ostacolo: perdita di 1 vita",
                targetRoom,
                () -> true, // Sempre selezionabile
                effects
        );

        choice.apply(game); // Applica gli effetti e cambia stanza
        assertEquals(currentLives - 1, player.getLives()); // Verifica il decremento di 1 vita
        assertEquals(targetRoom, game.getCurrentRoom()); // Verifica cambio stanza
    }

    /**
     * Test effetto infect: attiva l'infezione.
     */
    @Test
    public void testEffectInfect() {
        init(); // Inizializza
        assertFalse(player.isInfected()); // Inizialmente il player non è infetto (false)
        List<SerializableConsumer<Game>> effects = new ArrayList<>(); // Lista effetti
        effects.add(game -> game.getPlayers().get(0).infect()); // Effetto infect: infetta il giocatore
        
        // Scelta con l'effetto infect
        StoryChoice choice = new StoryChoiceImpl(
                12,
                "Aria tossica: ora sei infetto!",
                targetRoom,
                () -> true, // Sempre selezionabile
                effects
        );

        choice.apply(game); // Applica gli effetti e cambia stanza
        assertTrue(player.isInfected()); // Verifica che l'infezione sia attiva (true)
        assertTrue(player.getInfection().getRemainingTime() > 0); // Verifica che il timer infezione sia impostato (>0) (true)
        assertEquals(targetRoom, game.getCurrentRoom()); // Verifica cambio stanza
    }

    /**
     * Test effetto winner: imposta lo stato del player a WINNER.
     */
    @Test
    public void testEffectWinner() {
        init(); // Inizializza
        assertEquals(PlayerState.IS_PLAYING, player.getPlayerState()); // Verifica lo stato iniziale: IS_PLAYING
        List<SerializableConsumer<Game>> effects = new ArrayList<>(); // Lista effetti
        
        // Imposta direttamente lo stato del player a WINNER
        effects.add(g -> {
            g.getPlayers().get(0).setPlayerState(PlayerState.WINNER); // Effetto vittoria
            g.setGameState(GameState.OFF); // Termina partita
            g.addPendingMessage("Vittoria"); // Messaggio vittoria (se presente)
        });        

        // Scelta con l'effetto vittoria
        StoryChoice choice = new StoryChoiceImpl(
                13,
                "Sei libero: VITTORIA",
                targetRoom,
                () -> true, // Sempre selezionabile
                effects
        );

        choice.apply(game); // Applica gli effetti e cambia stanza
        assertEquals(PlayerState.WINNER, player.getPlayerState()); // Verifica lo stato finale: WINNER
        assertEquals(targetRoom, game.getCurrentRoom()); // Verifica cambio stanza

        // Verifica messaggio vittoria (se presente)
        List<String> pendingMessages = game.usePendingMessages(); // Lista messaggi
        assertTrue(pendingMessages.contains("Vittoria")); // Verifica la presenza del messaggio (true)
    }

    /**
     * Test effetto game over: imposta lo stato del player a GAME_OVER.
     */
    @Test
    public void testEffectGameOver() {
        init(); // Inizializza
        assertEquals(PlayerState.IS_PLAYING, player.getPlayerState()); // Verifica lo stato iniziale: IS_PLAYING
        List<SerializableConsumer<Game>> effects = new ArrayList<>(); // Lista effetti
        
        // Imposta direttamente lo stato del player a GAME_OVER
        effects.add(g -> {
            g.getPlayers().get(0).setPlayerState(PlayerState.GAME_OVER); // Effetto game over
            g.setGameState(GameState.OFF); // Termina partita
            g.addPendingMessage("Game over"); // Messaggio game over (se presente)
        });

        // Scelta con l'effetto game over
        StoryChoice choice = new StoryChoiceImpl(
                14,
                "Sei stato sconfitto: GAME OVER",
                targetRoom,
                () -> true, // Sempre selezionabile
                effects
        );

        choice.apply(game); // Applica gli effetti e cambia stanza
        assertEquals(PlayerState.GAME_OVER, player.getPlayerState()); // Verifica lo stato finale: GAME_OVER
        assertEquals(targetRoom, game.getCurrentRoom()); // Verifica cambio stanza
        
        // Verifica messaggio game over (se presente)
        List<String> pendingMessages = game.usePendingMessages(); // Lista messaggi
        assertTrue(pendingMessages.contains("Game over")); // Verifica la presenza del messaggio (true)
    }

    /**
     * Test effetto show_message: aggiunge un messaggio nei pending messages del Game.
     */
    @Test
    public void testEffectShowMessage() {
        init(); // Inizializza
        String msg = "Messaggio di test mostrato"; // Messaggio atteso
        List<SerializableConsumer<Game>> effects = new ArrayList<>(); // Lista effetti
        effects.add(game -> game.addPendingMessage(msg)); // Effetto show_message: aggiunge un messaggio

        // Scelta con l'effetto show_message
        StoryChoice choice = new StoryChoiceImpl(
                15,
                "Mostra messaggio",
                targetRoom,
                () -> true, // Sempre selezionabile
                effects
        );

        assertTrue(game.usePendingMessages().isEmpty()); // Verifica che non siano presenti messaggi prima di apply (true)
        choice.apply(game); // Applica gli effetti (aggiunge messaggio) e cambia stanza
        List<String> pendingMessages = game.usePendingMessages(); // Lista messaggi
        assertEquals(1, pendingMessages.size()); // Verifica che sia presente un solo messaggio
        assertEquals(msg, pendingMessages.get(0)); // Verifica la correttezza del messaggio
        assertEquals(targetRoom, game.getCurrentRoom()); // Verifica cambio stanza
    }
	
}
